package com.mycompany.a1;

import com.codename1.charts.util.ColorUtil;
import java.util.Random;

public abstract class GameObjects {
	
	private double locX;
	private double locY;
	private int color;
	private Random rdm;
	private int size;
	
	GameObjects(){
		setSize(0);
		setRdm(new Random());
		locX = 0;
		locY = 0;
		setColor(0);
		
	}

	public int getColour(){
		return color;
	}
	public String getColor(){
		String myColor;
		return myColor = "["+ColorUtil.red(color)+", "+ColorUtil.green(color)+", "+ColorUtil.blue(color)+" ]";
	}
	
	
	public double getLocX() {
		return locX;
	}

	
	public double getLocY() {
		return locY;
	}


	public void setLocX(double newX) {
		locX= newX;
	}

	public void setLocY(double newY) {
		locY= newY;
	}
	public void setColor(int color) {
		this.color = color;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Random getRdm() {
		return rdm;
	}

	public void setRdm(Random rdm) {
		this.rdm = rdm;
	}
}
