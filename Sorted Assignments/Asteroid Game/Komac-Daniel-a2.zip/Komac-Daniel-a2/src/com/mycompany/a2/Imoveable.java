package com.mycompany.a2;

public interface Imoveable {
	
	public void move();
	public double getLocX();
	public double getLocY();
	public int getDirection();
	public void setLocX(double newX);
	public void setLocY(double newY);
	
}
