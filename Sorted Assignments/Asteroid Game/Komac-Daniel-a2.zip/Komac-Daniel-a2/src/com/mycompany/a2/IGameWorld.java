package com.mycompany.a2;

public interface IGameWorld {
	
}
