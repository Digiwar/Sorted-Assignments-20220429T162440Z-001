package com.mycompany.a2;
import java.lang.Math;

public class RaceCarStrategy implements ICarStrategy{

	private Car npcCar;
	private GameWorld npcGW;
	
	public RaceCarStrategy(Car thisCar, GameWorld gw){
		npcCar = thisCar;
		npcGW = gw;
	}
	
	public String toString(){
		return "Race Strategy";
	}
	
	@Override
	public void applyStrategy() {
		// TODO Auto-generated method stub

		// the next pylon we want to go to
		int nextPylon = npcCar.getLastPylonReached() + 1;
		float pX = 0, 
			  pY = 0;
		
		// get an iterator for the collection
		IIterator anIterator = npcGW.gameObjectsList.getIterator();
		
		// setup a placeholder object
		Object currentObj = new Object();
		// iterate through, and check each one
		while( anIterator.hasNext() ){
			currentObj = anIterator.next();
			if(currentObj instanceof Pylon)
				if( ((Pylon)currentObj).getSequenceNumber() == nextPylon ){
					// found the next pylon they need to get to, save coordinates
					pX = ((Pylon)currentObj).getX();
					pY = ((Pylon)currentObj).getY();
				}
		}
		
		float dx, dy;
		
		// calculate the change
		dx = pX - npcCar.getX();
		dy = pY - npcCar.getY();
		
		// check for needing to move on axis, this also accounts
		// for checking of division by 0
		
		// is the y val the same?
		if( dy == 0 ){
			
			if( dx < 0 ){
				// target pylon is directly to the left
				npcCar.setHeading(270);
				return;
			}
			else if( dx > 0 ){
				// target pylon is directly to the right
				npcCar.setHeading(90);
				return;
			}
		}
		// is x val the same?
		if( dx == 0 )
			if( dy > 0 ){
				// target pylon is directly above
				npcCar.setHeading(0);
				return;
			}
			else if( dy < 0 ){
				// target pylon is directly below
				npcCar.setHeading(180);
				return;
			}
		
		// target wasn't at a 90 degree interval,
		// need to determine the angle
		
		int angle = (int)Math.toDegrees(1/(Math.tan((dx/dy))) );
		
		// got the angle, now figure out which quadrant to put it in
		if( dx > 0 ){ 
			if( dy > 0 ){
				// top right
				npcCar.setHeading( Math.abs(angle) );
				return;
			}
			else if( dy < 0){
				// bottom right
				npcCar.setHeading( 180 - angle );
				return;
			}
		}
		else if( dx < 0 ){
			if( dy > 0){
				// top left
				npcCar.setHeading( 360 - angle );
				return;
			}
			else if( dy < 0){
				// bottom left
				npcCar.setHeading( 180 + Math.abs(angle) );
				return;
			}
		}
		
	}
}


