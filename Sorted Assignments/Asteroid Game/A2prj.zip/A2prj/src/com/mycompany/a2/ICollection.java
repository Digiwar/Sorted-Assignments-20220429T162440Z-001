package com.mycompany.a2;

public interface ICollection {
	public void add(Object newObject);
	
	public void remove(Object newObject);
}
