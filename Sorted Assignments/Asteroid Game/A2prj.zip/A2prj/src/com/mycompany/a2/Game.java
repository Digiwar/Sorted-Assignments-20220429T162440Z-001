package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.mycompany.a2.GameWorld;

public class Game extends Form{
	
	private GameWorld gw;
	private MapView mv;
	private ScoreView sv;
	
	//adding buttons
	Button switchStratBtn = new Button("Switch Strategy");
	Button accelerateBtn = new Button("Accelerate");
	Button brakeBtn = new Button("Brake");
	Button rightBtn = new Button("Right");
	Button leftBtn = new Button("Left");
	Button exitBtn = new Button("Exit");
	Button npcCollideBtn = new Button("Collide With NPC");
	Button pylonCollideBtn = new Button("Collide With Pylon");
	Button birdCollideBtn = new Button("Collide With Bird");
	Button getFuelBtn = new Button("Pickup Fuel Can");
	Button tickBtn = new Button("Tick");
	
	//stylizer for the buttons
	private void buttonStyle(Button b){
		b.getUnselectedStyle().setBgTransparency(255);
		b.getUnselectedStyle().setFgColor(ColorUtil.WHITE);
		b.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
		b.getAllStyles().setPadding(Component.TOP, 5);
		b.getAllStyles().setPadding(Component.BOTTOM, 5);
	}
	
	AboutCommand cmdAbout = new AboutCommand();
	AccelerateCommand cmdAccelerate = new AccelerateCommand();
	BrakeCommand cmdBrake = new BrakeCommand();
	ChangeCarStrategyCommand cmdChangeStrat = new ChangeCarStrategyCommand();
	CollideWithBirdCommand cmdBird = new CollideWithBirdCommand();
	CollideWithCarCommand cmdCar = new CollideWithCarCommand();
	CollideWithPylonCommand cmdPylon = new CollideWithPylonCommand();
	PickUpFuelCommand cmdFuel = new PickUpFuelCommand();
	RightCommand cmdRight = new RightCommand();
	LeftCommand cmdLeft = new LeftCommand();
	SoundCommand cmdSound = new SoundCommand();
	TickCommand cmdTick = new TickCommand();
	ExitCommand cmdExit = new ExitCommand();
	HelpCommand cmdHelp = new HelpCommand();
	MapCommand cmdMap = new MapCommand();
	
	public Game() {
		this.setLayout(new BorderLayout());
		this.setTitle("Race Car Game");
		gw = new GameWorld(); //initializes game world
		gw.init(); //initializes game objects
		mv = new MapView(gw);
		sv = new ScoreView();
		gw.addObserver(mv);
		gw.addObserver(sv);
		gw.setChange();
		this.add(BorderLayout.NORTH, sv);
		this.add(BorderLayout.CENTER, mv);
		
		//setting targets for commands
		cmdAbout.setTarget(gw);
		cmdAccelerate.setTarget(gw);
		cmdBrake.setTarget(gw);
		cmdChangeStrat.setTarget(gw);
		cmdBird.setTarget(gw);
		cmdCar.setTarget(gw);
		cmdPylon.setTarget(gw);
		cmdFuel.setTarget(gw);
		cmdRight.setTarget(gw);
		cmdLeft.setTarget(gw);
		cmdSound.setTarget(gw);
		cmdTick.setTarget(gw);
		cmdExit.setTarget(gw);
		cmdHelp.setTarget(gw);
		cmdMap.setTarget(gw);
		
		switchStratBtn.setCommand(cmdChangeStrat);
		accelerateBtn.setCommand(cmdAccelerate);
		brakeBtn.setCommand(cmdBrake);
		rightBtn.setCommand(cmdRight);
		leftBtn.setCommand(cmdLeft);
		tickBtn.setCommand(cmdTick);
		exitBtn.setCommand(cmdExit);
		npcCollideBtn.setCommand(cmdCar);
		birdCollideBtn.setCommand(cmdBird);
		pylonCollideBtn.setCommand(cmdPylon);
		getFuelBtn.setCommand(cmdFuel);
		
		//KeyListeners
		addKeyListener('a', cmdAccelerate);
		addKeyListener('b', cmdBrake);
		addKeyListener('l', cmdLeft);
		addKeyListener('r', cmdRight);
		addKeyListener('c', cmdCar);
		addKeyListener('f', cmdFuel);
		addKeyListener('t', cmdTick);
		addKeyListener('e', cmdExit);
		addKeyListener('m', cmdMap);

		
		//Toolbar
		Toolbar toolbar = new Toolbar();
		this.setToolbar(toolbar);
		CheckBox cb = new CheckBox("Sound");
		cb.setCommand(cmdSound);
		cb.getUnselectedStyle().setBgTransparency(255);
		cb.getUnselectedStyle().setBgColor(ColorUtil.LTGRAY);
		cmdSound.putClientProperty("SideComponent", cb);
		toolbar.addCommandToSideMenu(cmdSound);
		toolbar.addCommandToSideMenu(cmdAbout);
		toolbar.addCommandToSideMenu(cmdExit);
		toolbar.addCommandToRightBar(cmdHelp);

		//Left Container
		Container leftContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		leftContainer.getAllStyles().setPadding(Component.TOP, 50);
		leftContainer.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLUE));
		buttonStyle(switchStratBtn); //switchStratBtn Button
		leftContainer.add(switchStratBtn);
		buttonStyle(accelerateBtn); //accel button
		leftContainer.add(accelerateBtn);
		buttonStyle(brakeBtn); //brake button
		leftContainer.add(brakeBtn);
		buttonStyle(rightBtn); //right Button
		leftContainer.add(rightBtn);
		buttonStyle(leftBtn); //Left Button
		leftContainer.add(leftBtn);
		buttonStyle(exitBtn);
		leftContainer.add(exitBtn);
		add(BorderLayout.WEST, leftContainer);
		
		Container bottomContainer = new Container(new FlowLayout(Component.CENTER));
		bottomContainer.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLUE));
		buttonStyle(npcCollideBtn); //collide with npc Button
		bottomContainer.add(npcCollideBtn);
		buttonStyle(pylonCollideBtn); //collide with pylon button
		bottomContainer.add(pylonCollideBtn);
		buttonStyle(birdCollideBtn); //collide with bird button
		bottomContainer.add(birdCollideBtn);
		buttonStyle(getFuelBtn); //get fuel Button
		bottomContainer.add(getFuelBtn);
		buttonStyle(tickBtn); //tick Button
		bottomContainer.add(tickBtn);
		add(BorderLayout.SOUTH, bottomContainer);
				
				

				

		this.show();
		//play();
	}
	
	/*private void play() { //method to generate gui and input as well as accept input for game commands
		 Label myLabel=new Label("Enter a Command:");
		 this.addComponent(myLabel);
		 final TextField myTextField=new TextField();
		 this.addComponent(myTextField);
		 this.show();
		 myTextField.addActionListener(new ActionListener<ActionEvent>() {
		 public void actionPerformed(ActionEvent evt) {
			 String sCommand=myTextField.getText().toString();
			 myTextField.clear();
			 if(sCommand.equals("")) {
				 System.out.println("You must enter a legal command.");
			 }
			 else {
				 switch (sCommand.charAt(0)) {
					 case 'a'://kinda, cant accel after getting hit
						 gw.acceleratePlayer();
						 System.out.println("car is accelerating.");
						 break;
					 case 'b'://brakes player car
						 gw.brakePlayer();
						 System.out.println("brakes are applied.");
						 break;
					 case 'l'://steers player left
						 gw.turnPlayerLeft();
						 System.out.println("steering to the left.");
						 break;
					 case 'r'://steers player right
						 gw.turnPlayerRight();
						 System.out.println("steering to the right.");
						 break;	 
					 case 'c'://pretends player gets hit by another car
						 gw.playerCarCollision();
						 System.out.println("oh no! you've collided with another car.");
						 break;
					 case '0'://numbers 0 - 9 will pretend player reaches that pylon if in consecutive order
						 gw.playerHitPylon(0);
						 System.out.println("you've reached pylon 0");
						 break;
					 case '1':
						 gw.playerHitPylon(1);
						 System.out.println("you've reached pylon 1");
						 break;
					 case '2':
						 gw.playerHitPylon(2);
						 System.out.println("you've reached pylon 2");
						 break;
					 case '3':
						 gw.playerHitPylon(3);
						 System.out.println("you've reached pylon 3");
						 break;
					 case '4':
						 gw.playerHitPylon(4);
						 System.out.println("you've reached pylon 4");
						 break;
					 case '5':
						 gw.playerHitPylon(5);
						 System.out.println("you've reached pylon 5");
						 break;
					 case '6':
						 gw.playerHitPylon(6);
						 System.out.println("you've reached pylon 6");
						 break;
					 case '7':
						 gw.playerHitPylon(7);
						 System.out.println("you've reached pylon 7");
						 break;
					 case '8':
						 gw.playerHitPylon(8);
						 System.out.println("you've reached pylon 8");
						 break;
					 case '9':
						 gw.playerHitPylon(9);
						 System.out.println("you've reached pylon 9");
						 break;	 
					 case 'f'://working with java.util.ConcurrentModificationException error, gives player fuel
						 gw.playerGetsFuelCan();
						 System.out.println("you've picked up some fuel");
						 break;
					 case 'g'://bird colides with player car
						 gw.playerBirdCollision();
						 System.out.println("some gunk dropped on you from the bird above");
						 break;
					 case 't'://advances the game clock
						 gw.tick();
						 System.out.println("advance clock");
						 break;
					 case 'd'://prints the state of the game
						 gw.getGameState();
						 break;
					 case 'm'://prints the map of objects
						 gw.map();
						 break;
					 case 'x'://works
						 System.out.println ("Are you sure you want to exit? Type 'Y' for yes, 'N' for no");
						 break;
					 case 'y'://works
						 System.exit(0);
						 break;
					 case 'n'://works
						 //Do nothing
						 break;
					 default:
						 System.out.println("You must enter a legal command.");
						 break;
				 } //switch
			 }
		 } } ); //addActionListener 	 
	 }*/

}

