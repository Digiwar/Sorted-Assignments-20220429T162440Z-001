package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;

public class HelpCommand extends Command{

	private GameWorld gw = new GameWorld();
	public HelpCommand() {
		super("Help.");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String s = "a - accelerate the car\n"
				+ "b - apply the brakes\n"
				+ "l - left turn\n"
				+ "r - right turn\n"
				+ "f - pick up fuel\n"
				+ "t - advance game clock\n"
				+ "e - exit game";
		Dialog.show("Commands", s, "OK", null);
	}
	
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
