package com.mycompany.a2;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;

public class FuelCan extends Fixed{
	
	//how much fuel is in the can
	private int capacity;
	
	//used to create random integers
	public static int randInt(int min, int max) {
	    Random rand = new Random();
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
	
	//create a fuel can with random location, capacity, but solid color
	public FuelCan(){
		setLocation((float)randInt(0,1024), (float)randInt(0,768));
		setCapacity(randInt(0,25));
		setSize(this.capacity);
		super.setColor(ColorUtil.CYAN);
	}
	
	//overloads fuelcan to create with set location, color, capacity 
	public FuelCan(float x, float y, int color, int capacity){
		setLocation(x,y);
		super.setColor(color);
		setCapacity(capacity);
		setSize(capacity);
	}
	
	//getter for capacity
	public int getCapacity() {
		return capacity;
	}

	//setter for capacity
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	//overides tostring for fuelcan attributes
	@Override
	public String toString(){
		return "FuelCan: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())+"]" 
				+ " size=" + this.getCapacity();
	}
	
	
}
