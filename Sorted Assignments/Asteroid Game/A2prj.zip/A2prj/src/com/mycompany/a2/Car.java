package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;

public class Car extends Movable implements ISteerable{
	
	private int steeringDirection;
	private float maximumSpeed;
	private int fuelLevel;
	private int fuelConsumptionRate;
	private int damageLevel;
	private int lastPylonReached;
	private int maxDamage;
	private final int MAXIMUM_TURN_RADIUS = 40;

	
	//creates a car with set location heading speed and color
	public Car(float x, float y, int heading, int speed, int color){
		super.setSize(40);
		this.setSteeringDirection(0);
		this.setMaximumSpeed(50);
		this.setDamageLevel(0);
		this.setLocation(x, y);
		this.setHeading(heading);
		super.setSpeed(speed);
		super.setColor(color);
		this.setmaxDamage(10);
	}
	
	
	//modifies steering direction 5 degrees to the right
	public void steerRight() {
		if( steeringDirection < (MAXIMUM_TURN_RADIUS - 4) ){
			steeringDirection += 5;
			this.setHeading(this.getHeading() + this.steeringDirection);
			
		}
	}

	//modifies steering direction 5 degrees to the left
	public void steerLEft() {
		if( steeringDirection > (4 - MAXIMUM_TURN_RADIUS) ){
			steeringDirection -= 5;
			this.setHeading(this.getHeading() + this.steeringDirection);
			
		}
	}
	
	//moves the car
	@Override
	public void move() {
		this.setHeading( this.getHeading() + steeringDirection );
		if (this.getHeading() > 360){
			this.setHeading(this.getHeading() - 360);
		}
		else if (this.getHeading() < -360){
			this.setHeading(this.getHeading() + 360);
		}
		useFuel(1);
		int angle = 90 - this.getHeading();
		float deltaX = ( ((float)Math.cos( Math.toRadians(angle) )) * this.getSpeed());
		float deltaY = ( ((float)Math.sin( Math.toRadians(angle) )) * this.getSpeed());
		float newX = this.getX() + deltaX;
		float newY = this.getY() + deltaY;
		super.setLocation( newX, newY );
		checkSpeed();		
	}

	//gets the steer direction
	public int getSteeringDirection() {
		return steeringDirection;
	}

	//set the steer direction
	public void setSteeringDirection(int steeringDirection) {
		this.steeringDirection = steeringDirection;
	}

	//gets the max speed
	public float getMaximumSpeed() {
		return maximumSpeed;
	}

	//sets the max speed
	public void setMaximumSpeed(int maximumSpeed) {
		this.maximumSpeed = maximumSpeed;
	}

	//gets the fuel level
	public int getFuelLevel() {
		return fuelLevel;
	}
	
    // sets the fuel level
	public void setFuelLevel(int fuelLevel) {
		this.fuelLevel = fuelLevel;
	}

	//gets how much fuel the car uses
	public int getFuelConsumptionRate() {
		return fuelConsumptionRate;
	}

	//sets how much fuel the car loses
	public void setFuelConsumptionRate(int fuelConsumptionRate) {
		this.fuelConsumptionRate = fuelConsumptionRate;
	}

	//gets the damage level of the car
	public int getDamageLevel() {
		return damageLevel;
	}

	//sets the dmg level of the car
	public void setDamageLevel(int damageLevel) {
		this.damageLevel = damageLevel;
	}

	//gets the last pylon the car reached
	public int getLastPylonReached() {
		return lastPylonReached;
	}

	//sets the last pylon that the car reached
	public void setLastPylonReached(int lastPylonReached) {
		this.lastPylonReached = lastPylonReached;
	}

	//gets the max dmg
	public int getmaxDamage() {
		return maxDamage;
	}
	
	public void setmaxDamage(int i){
		this.maxDamage = i;
	}

	//gets the max turn radius
	public int getMAXIMUM_TURN_RADIUS() {
		return MAXIMUM_TURN_RADIUS;
	}
	
	//prevents car from changing color
	public void setColor(){
		
	}
	
	//prevents the car from changing its size
	public void setSize(){
		
	}
	
	//adjust the speed of the car according to its dmg and fuel level
	public void checkSpeed(){
		if( getSpeed() > ( maximumSpeed * ( (maxDamage - damageLevel) / maxDamage))){
			setSpeed((getSpeed()*(maxDamage-damageLevel)/ maxDamage));
		}
		if( getFuelLevel() == 0)
			setSpeed(0);	
	}
	
	
	//reduces fuel from car
	private void useFuel(int fuel){
		if (getFuelLevel() > 0){
			fuelLevel -= fuel;
		}
		if (getFuelLevel() < 0){
			fuelLevel = 0;
		}
	}
	
	//adds speed to car
	public void accelerate(){
		float accel = (float) 3.0;
		//if( getSpeed() < (maximumSpeed * ((maxDamage - damageLevel)/maxDamage))){
		this.setSpeed( this.getSpeed() + (accel*(maxDamage-damageLevel)/ maxDamage));
		//}
	}
	
	//reduces speed from car
	public void brake(){
		if( getSpeed() > 0 ){
			setSpeed( getSpeed() - 3);
		}	
		if( getSpeed() < 0){
			setSpeed(0);
		}
	}
	
	//adds fuel to car
	public void addFuel(int Fuel){
		fuelLevel += Fuel;
	}
	
	//adds damage to car
	public void addDamage(int damage){
		damageLevel += damage;
		this.checkSpeed();
	}
	
	//Overrides to string to show car attributes
	@Override
	public String toString(){
		String carString = "Car: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())
				+"]" +" heading="+this.getHeading()+" speed="+this.getSpeed()
				+ " size=" + this.getSize()+ " maxSpeed="+this.getMaximumSpeed()+" steeringDirection="
				+this.getSteeringDirection()+ " fuelLevel="+this.getFuelLevel()+" damageLevel="+
				this.getDamageLevel();
		carString += " type= player";
		return carString;
	}
	
}
