package com.mycompany.a2;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;

public class Pylon extends Fixed{
	
	//number that represents the pylon
	private int sequenceNumber;
	
	//used to create random number range
	public static int randInt(int min, int max) {
	    Random rand = new Random();
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
	
	//initializes a pylon with a location, color, and sequence number
	public Pylon(float x, float y, int color, int seqNum){
		setLocation(x,y);
		super.setColor(color);
		setSequenceNumber(seqNum);
	}
	
	//gets the seq number
	public int getSequenceNumber() {
		return sequenceNumber;
	}
	
	//sets the seq number
	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	
	//will not be able to change color after created
	public void setColor(){
		//empty to not be able to change color
	}
	
	//will not be able to change size after created
	public void setSize(){
		//empty to avoid setting size
	}
	
	//overides tostring to pylons attributes
	@Override
	public String toString(){
		return "Pylon: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())+"]" 
				+ " seqNum=" + this.getSequenceNumber();
	}

}
