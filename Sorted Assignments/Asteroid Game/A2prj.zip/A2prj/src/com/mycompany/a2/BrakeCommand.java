package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class BrakeCommand extends Command{

	private GameWorld gw = new GameWorld();
	public BrakeCommand() {
		super("Brake");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.brakePlayer();
	}
	
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
