package com.mycompany.a2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observer;
import java.util.Observable;
import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.mycompany.a2.Bird;
import com.mycompany.a2.Car;
import com.mycompany.a2.FuelCan;
import com.mycompany.a2.Pylon;


public class GameWorld extends Observable{
	
	GameObjectCollection gameObjectsList = new GameObjectCollection();
	private ArrayList<Observer> observers;
	ScoreView sv = new ScoreView();

	private static final int GAME_SIZE_WIDTH = 1024;
	private static final int GAME_SIZE_HEIGHT = 768;
	private static final int PYLON_COLOR = ColorUtil.WHITE;
	private boolean livesRemaining = true;
	private boolean sound;
	private int clock = 0;
	private int lives = 3;
	private int initCarColor = 255;
	private int usedFuelCanColor = 100;
	private int CAR_COLOR = ColorUtil.rgb(initCarColor,0,0);
	
	//private Factory f;
	private Bird bird1;
	private Bird bird2;
	private FuelCan fuelCan1;
	private FuelCan fuelCan2;
	protected Car playerCar;
	protected NonPlayerCar NPC1;
	protected NonPlayerCar NPC2;
	protected NonPlayerCar NPC3;
	private Pylon pylon1;
	private Pylon pylon2;
	private Pylon pylon3;
	private Pylon pylon4;
	
	//loads all the objects into the game, adds to an array so i can print them later
	public void init(){

		
		bird1 = new Bird();
		gameObjectsList.add(bird1);
		bird2 = new Bird();
		gameObjectsList.add(bird2);
		playerCar = new Car(200, 200 , 0, 0, CAR_COLOR);
		gameObjectsList.add(playerCar);
		NPC1 = new NonPlayerCar(playerCar.getX()+50, 200 , 0, 0, ColorUtil.MAGENTA);
		NPC1.setStrategy(new AttackCarStrategy(NPC1, playerCar));
		gameObjectsList.add(NPC1);
		NPC2 = new NonPlayerCar(NPC1.getX()+50, 200 , 0, 0, ColorUtil.MAGENTA);
		NPC2.setStrategy(new AttackCarStrategy(NPC2, playerCar));
		gameObjectsList.add(NPC2);
		NPC3 = new NonPlayerCar(NPC2.getX()+50, 200 , 0, 0, ColorUtil.MAGENTA);
		NPC3.setStrategy(new AttackCarStrategy(NPC3, playerCar));
		gameObjectsList.add(NPC3);
		fuelCan1 = new FuelCan();
		gameObjectsList.add(fuelCan1);
		fuelCan2 = new FuelCan();
		gameObjectsList.add(fuelCan2);
		pylon1 = new Pylon(200, 200, PYLON_COLOR, 1);
		gameObjectsList.add(pylon1);
		pylon2 = new Pylon(200, 800, PYLON_COLOR, 2);
		gameObjectsList.add(pylon2);
		pylon3 = new Pylon(700, 800, PYLON_COLOR, 3);
		gameObjectsList.add(pylon3);
		pylon4 = new Pylon(900, 400, PYLON_COLOR, 4);
		gameObjectsList.add(pylon4);

		setChange();
		
		map();
		
	}

	// get the world height
	public static int getGameSizeHeight() {
		return GAME_SIZE_HEIGHT;
	}

	// gets the game width
	public static int getGameSizeWidth() {
		return GAME_SIZE_WIDTH;
	}

	//gets the clock time
	public int getClock() {

		return clock;
	}

	//sets the clock time
	public void setClock(int clock) {
		this.clock = clock;
	}

	//gets the amt of lives
	public int getLives() {

		return lives;
	}

	//sets the amt of lives
	public void setLives(int lives) {
		this.lives = lives;
	}
	
	
	//restarts the game if the number of lives left = 0
	public void restartGame(){
		//Check if player has lives left
		livesRemaining = this.anyLivesRemaining();
		if (livesRemaining){
			init();//Restart game
			this.setLives(this.getLives()-1);
			playerCar.setDamageLevel(0);
		}
		else{
			int livesLeft = this.getLives() - 1;
			System.out.println();	//Game over
			System.out.println("You have " + livesLeft + " lives remaining.");
			System.out.println("Game Over.");
			System.exit(0);
		}
		setChange();
		
	}
	
	//returns true or false based on lives left
	public boolean anyLivesRemaining (){
		//Return true of player has lives left
		// false otherwise
		if (lives > 1){
			setChange();
			return true;
		}
		setChange();
		return false;
	}
	
	//prints out initial map of all game objects, call again to print again
	public void map() {
		// get an iterator for the collection
		IIterator myIterator = gameObjectsList.getIterator();
				
		// setup a placeholder object
		Object currentObject = new Object();
				
		// iterate through, and print each one
		while( myIterator.hasNext() ){
			currentObject = myIterator.next();
			System.out.println( currentObject.toString() );
		}
	}
	
	//Call to advance the game clock for all movable objects
	//also, for each tick, checks if the heading is above or 
	//below 360 or -360 degrees and resets the scale
	public void tick() {
		IIterator myIterator = gameObjectsList.getIterator();
		
		Object currentObject = new Object();
				
		this.setClock(getClock() + 1);
		
		while(myIterator.hasNext() ) {
			currentObject = myIterator.next();
			if(currentObject instanceof Movable) {
				Movable moveObj = (Movable) currentObject;
				moveObj.move();
			}
		}
		setChange();
	}
	
	//creates random int inside range
	public static int randInt(int min, int max) {
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}
	
	//sets last pylon reached to pylon seqnum
	public boolean playerHitPylon(int p){
		// player can only activate this pylon if it is
		// the one immediately after the last one they hit
		if( p == (playerCar.getLastPylonReached() + 1) ){
			// update the player's pylon progress
			playerCar.setLastPylonReached(p);
			setChange();
			return true;
			}
		
		// player didn't hit the next valid pylon
		return false;
	}
	
	//adds fuel to car, changes can color to light green, depletes can of fuel, spawns another can
	public boolean playerGetsFuelCan(){
		IIterator myIterator = gameObjectsList.getIterator();
		Object currentObject = new Object();
		
		while(myIterator.hasNext()){
			currentObject = myIterator.next();
			if(currentObject instanceof FuelCan){
				if (((FuelCan) currentObject).getColor() == ColorUtil.rgb(0, 255, 255)){
					playerCar.addFuel(((FuelCan) currentObject).getCapacity());
					((FuelCan) currentObject).setColor(ColorUtil.rgb(0, usedFuelCanColor, 0));
					((FuelCan) currentObject).setCapacity(0);	
					FuelCan newCan = new FuelCan();
					gameObjectsList.add(newCan);
					setChange();
					return true;
				}	
			}
		}
		return false;
	}
	
	//colides with bird, adds dmg to car, fades car color
	public void playerBirdCollision(){
		if (initCarColor > 10)
			initCarColor = initCarColor - 10;
		this.addDamage(1);
		
		playerCar.setColor(ColorUtil.rgb(initCarColor, 0, 0));
		setChange();
	}
	
	//collides with car, adds dmg to car
	public void playerCarCollision(){
		this.addDamage(2);	
	}
	
	//adds dmg to car and modifies speed based off dmg level
	public void addDamage(int damage){
		if(playerCar.getDamageLevel()+damage >= playerCar.getmaxDamage()){
			this.restartGame();
		}
		else{
			playerCar.setDamageLevel(playerCar.getDamageLevel() + damage);
			playerCar.checkSpeed();
		}
		setChange();
	}
	
	//slows down car
	public void brakePlayer(){
		playerCar.brake();
		setChange();
	}
	
	//speeds up car
	public void acceleratePlayer(){
		playerCar.accelerate();
		setChange();
	}
	
	//turns car right
	public void turnPlayerRight(){
		playerCar.steerRight();
		setChange();
	}
	
	//turns car left
	public void turnPlayerLeft(){
		playerCar.steerLEft();
		setChange();	
	}
	
	//gets the state of the game
	public void getGameState(){
		System.out.println(
			   "Lives left: "+ this.getLives()+ "\n"+ 
			   "Current clock time: "+ this.getClock()+ "\n"+
			   "Highest pylon reached: "+ playerCar.getLastPylonReached()+ "\n"+
			   "Current player fuel: "+ playerCar.getFuelLevel()+ "\n"+
			   "Current player damage level: "+ playerCar.getDamageLevel()+ "\n"+
			   "Player Max Damage: "+ playerCar.getmaxDamage()+ "\n");

	}

	public boolean isSound() {

		return sound;	
	}

	public void setSound(boolean sound) {
		this.sound = sound;
		setChange();

	}
	
	public int getLastPylon(){
		return playerCar.getLastPylonReached();
	}  
	
	public int getFuelRemaining(){
		return playerCar.getFuelLevel();
	}
	
	public int getDamageLevel(){
		return playerCar.getDamageLevel();
	}
	
	//Updates observers
	public void setChange() {
		setChanged();
		notifyObservers();
		//map();
	}
	
	// go through and change strategies of all NPCs
	public void changeNPCStrategies(){
		IIterator anIterator = gameObjectsList.getIterator();
		
		Object currentObj = new Object();
		
		while( anIterator.hasNext() ){
			currentObj = anIterator.next();
			if( currentObj instanceof NonPlayerCar){ // found a car
				
				// increase its highest pylon count
				((NonPlayerCar)currentObj).setLastPylonReached(( ((NonPlayerCar)currentObj).getLastPylonReached() + 1 ));
				
				// just make a NPC method changeStrat() and changeStrat(ICarStrat) 
				if( ((NonPlayerCar)currentObj).getStrategy() instanceof RaceCarStrategy ){
					((NonPlayerCar)currentObj).setStrategy(new AttackCarStrategy(((NonPlayerCar)currentObj), playerCar ));
				} else if ( ((NonPlayerCar)currentObj).getStrategy() instanceof AttackCarStrategy ){
					((NonPlayerCar)currentObj).setStrategy(new RaceCarStrategy(((NonPlayerCar)currentObj), this));
				}
			}
		}
	}

}
