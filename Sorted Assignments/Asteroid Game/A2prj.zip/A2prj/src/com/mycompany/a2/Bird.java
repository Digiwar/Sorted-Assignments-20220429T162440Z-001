package com.mycompany.a2;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;

public class Bird extends Movable{
	
	//heading, speed, color, size
	
	//creates a random bird with random heading, size, color, speed
	public Bird(){
		setLocation((float)randInt(0,1024), (float)randInt(0,768));
		super.setSize(randInt(0,20));
		super.setColor(ColorUtil.GREEN);
		setHeading(randInt(0,359));
		setSpeed(randInt(5,20));
	}

	//overloads Bird to create with set location, color, capacity 
	public Bird(float x, float y, int color, int size, int speed){
		setLocation(x,y);
		super.setColor(color);
		super.setSize(size);
		setHeading(randInt(0,359));
		setSpeed(speed);
	}
	
	//used to create random integers
	public static int randInt(int min, int max) {
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}
	
	//makes it so bird cant change color after being created
	public void setColor(){
		
	}

	//moves the bird a distance according to its heading and speed, also it it is at an edge it will turn until its no longer there
	@Override
	public void move() {
		int angle = 90 - this.getHeading();
		float deltaX = ( ((float)Math.cos( Math.toRadians(angle) )) * this.getSpeed());
		float deltaY = ( ((float)Math.sin( Math.toRadians(angle) )) * this.getSpeed());
		float newX = this.getX() + deltaX;
		float newY = this.getY() + deltaY;
		this.setLocation( newX, newY );
		int rando = randInt(1,2);
		if (rando == 1){
			this.setHeading(this.getHeading() + randInt(0,20));
		}
		else if (rando == 2){
			this.setHeading(this.getHeading() - randInt(0,20));
		}
		if (this.getHeading() > 360){
			this.setHeading( this.getHeading() - 360);
		}
		else if (this.getHeading() < -360){
			this.setHeading( this.getHeading() + 360);
		}
		//try to redirect the bird back onto the map, like a roomba
		if (newX <= 0 || newX >= 1024 || newY <= 0 || newY >= 768){
			this.setHeading(this.getHeading()+90);
		}
		
	}
	
	//prevents bird from changing size after creation
	public void setSize(){
		
	}
	
	//overides tosting to display bird attributes
	@Override
	public String toString(){
		return "Bird: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())+"] heading="+this.getHeading()+", "
				+ "speed="+ this.getSpeed()+ ", size=" + this.getSize();
	}

}
