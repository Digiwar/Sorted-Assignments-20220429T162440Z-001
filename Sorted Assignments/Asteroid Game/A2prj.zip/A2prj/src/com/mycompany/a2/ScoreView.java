package com.mycompany.a2;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.FlowLayout;

public class ScoreView extends Container implements Observer{
	
	private GameWorld gw;
	private Label tTimeLabel = new Label("Time:");
	private Label tLivesLabel = new Label(" Lives Left:");
	private Label tPylonLabel = new Label("Highest Player Pylon:");
	private Label tFuelLabel = new Label("Player Fuel Remaining:");
	private Label tDamageLabel = new Label("Player Damage Level:");
	private Label tSoundLabel = new Label("Sound:");
	private Label timeLabel = new Label(" 0");
	private Label livesLabel = new Label(" 0");
	private Label pylonLabel = new Label(" 0");
	private Label fuelLabel = new Label(" 0");
	private Label damageLabel = new Label(" 0");
	private Label soundLabel = new Label("OFF");
	private Label[] labels = {tTimeLabel, tLivesLabel, tPylonLabel, tFuelLabel,
			tDamageLabel, tSoundLabel};
	private Label[] subLabels = {timeLabel, livesLabel, pylonLabel,
			fuelLabel, damageLabel, soundLabel};
	
	public ScoreView(){
		this.setLayout(new FlowLayout(Component.CENTER));
		
		for(int i = 0; i < labels.length; i++) {
			labels[i].getUnselectedStyle().setFgColor(ColorUtil.BLUE);
			labels[i].getUnselectedStyle().setBgTransparency(255);
			labels[i].getUnselectedStyle().setBgColor(ColorUtil.WHITE);
		}
		for(int i = 0; i < subLabels.length; i++) {
			subLabels[i].getUnselectedStyle().setFgColor(ColorUtil.BLUE);
			subLabels[i].getUnselectedStyle().setBgTransparency(255);
			subLabels[i].getUnselectedStyle().setBgColor(ColorUtil.WHITE);
			subLabels[i].getUnselectedStyle().setPadding(Component.RIGHT, 5);
		}
		
		this.add(tTimeLabel);
		this.add(timeLabel);
		this.add(tDamageLabel);
		this.add(damageLabel);
		this.add(tFuelLabel);
		this.add(fuelLabel);
		this.add(tLivesLabel);
		this.add(livesLabel);
		this.add(tPylonLabel);
		this.add(pylonLabel);
		this.add(tSoundLabel);
		this.add(soundLabel);
	}
	
	@Override
	public void update(Observable observable, Object data){
		// TODO Auto-generated method stub
		gw = (GameWorld) observable;
		int time = gw.getClock();
		int livesLeft = gw.getLives();
		int highPylon = gw.getLastPylon();
		int fuelRemaining = gw.getFuelRemaining();
		int damageLevel = gw.getDamageLevel();
		boolean sound = gw.isSound();
		
		this.timeLabel.setText(time+"");
		this.livesLabel.setText(livesLeft+"");
		this.pylonLabel.setText(highPylon+"");
		this.fuelLabel.setText(fuelRemaining+"");
		this.damageLabel.setText(damageLevel+"");
		if (sound){
			this.soundLabel.setText("ON");
		} 
		else{
			this.soundLabel.setText("OFF");
		}
		
	}

}
