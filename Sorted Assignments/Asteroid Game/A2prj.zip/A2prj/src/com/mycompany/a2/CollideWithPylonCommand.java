package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;

public class CollideWithPylonCommand extends Command{

	private GameWorld gw = new GameWorld();
	private String inputString;
	public CollideWithPylonCommand() {
		super("Tagged a pylon");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		Command cOk = new Command("Ok");
		Command cCancel = new Command("Cancel");
		Command[] cmds = new Command[]{cOk,cCancel};
		TextField myTF = new TextField();
		Command c = Dialog.show("Enter pylon number", myTF, cmds);
		if (c == cOk){
			gw.playerHitPylon(myTF.getAsInt(0));
		}	
	}
	
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}

	public String getInputString() {
		return inputString;
	}

	public void setInputString(String inputString) {
		this.inputString = inputString;
	}
	
	
}
