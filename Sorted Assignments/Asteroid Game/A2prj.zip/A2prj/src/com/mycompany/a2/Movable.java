package com.mycompany.a2;

//class for movable objects to extend from
public abstract class Movable extends GameObject{
	
	private int heading;
	private float speed;
	
	//gets the heading of the object
	public int getHeading() {
		return heading;
	}
	
	//sets the heading of the object
	public void setHeading(int heading) {
		this.heading = heading;
	}
	
	//gets the speed of the object
	public float getSpeed() {
		return speed;
	}
	
	//sets the speed of the object
	public void setSpeed(float f) {
		this.speed = f;
	}
	
	//all movable objects will be able to move
	public abstract void move();

}
