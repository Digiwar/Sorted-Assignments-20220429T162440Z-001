package com.mycompany.a2;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer{
	
	private GameWorld gw;
	
	public MapView(GameWorld gw){
		this.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.BLUE));
		this.gw = gw;
	}

	@Override
	public void update(Observable observable, Object data) {
		gw = (GameWorld) observable;
		if(gw.getLives() <= 0){
			if (Dialog.show("Game Over", "Final Score" +gw.getLives(), "Exit", null)){
				System.exit(0);
			}
		}
	}




}
