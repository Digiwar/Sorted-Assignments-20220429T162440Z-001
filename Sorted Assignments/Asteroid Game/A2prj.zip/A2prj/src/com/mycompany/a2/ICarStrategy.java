package com.mycompany.a2;

public interface ICarStrategy {

	public void applyStrategy();
	
}
