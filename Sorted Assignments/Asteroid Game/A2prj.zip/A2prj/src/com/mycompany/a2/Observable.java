package com.mycompany.a2;

import java.util.Observer;

public class Observable implements Observer{

	@Override
	public void update(java.util.Observable observable, Object data) {
		// TODO Auto-generated method stub
		
	}

}
