package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;

public class NonPlayerCar extends Car{

	private ICarStrategy curStrategy;
	
	public NonPlayerCar(float x, float y, int heading, int speed, int color) {
		super(x, y, heading, speed, color);
		// TODO Auto-generated constructor stub
		setmaxDamage(30);
		setFuelLevel(1000);
	}
	
	public void move(){
		invokeStrategy();
		super.move();
	}

	// code for applying strategies from IStrategy interface
	public ICarStrategy getStrategy(){
		return curStrategy;
	}
	
	public void setStrategy(ICarStrategy s){
		this.curStrategy = s;
	}
	
	public void invokeStrategy(){
		curStrategy.applyStrategy();
	}

	@Override
	public String toString(){
		String npcString = "Car: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())
				+"]" +" heading="+this.getHeading()+" speed="+this.getSpeed()
				+ " size=" + this.getSize()+ " maxSpeed="+this.getMaximumSpeed()+" steeringDirection="
				+this.getSteeringDirection()+ " fuelLevel="+this.getFuelLevel()+" damageLevel="+
				this.getDamageLevel();
		npcString += " type= NPC strategy = " +curStrategy.toString();
		return npcString;
	}
	
}
