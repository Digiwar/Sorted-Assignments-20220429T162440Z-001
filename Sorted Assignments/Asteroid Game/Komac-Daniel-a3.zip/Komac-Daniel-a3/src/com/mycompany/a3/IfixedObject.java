package com.mycompany.a3;

public interface IfixedObject {
	

	public int getUnID();
	public void setLocX(double newX);
	public void setLocY(double newY);
	public double getLocX();
	public double getLocY();
	
}
