package com.mycompany.a3;

public interface ICollection {
	public void add(Object newObj);
	
	public IIterator getIterator();
	
}
