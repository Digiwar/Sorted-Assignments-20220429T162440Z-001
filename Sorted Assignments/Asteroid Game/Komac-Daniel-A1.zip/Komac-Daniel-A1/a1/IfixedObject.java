package com.mycompany.a1;

public interface IfixedObject {
	

	public int getUnID();
	public void setLocX(double newX);
	public void setLocY(double newY);
	public double getLocX();
	public double getLocY();
	
}
