README:
Added sound for bird collisions "splat"


line that was used to run from cmdLine:
java -cp dist\A3prj.jar;JavaSE.jar com.codename1.impl.javase.Simulator com.mycompany.a3
