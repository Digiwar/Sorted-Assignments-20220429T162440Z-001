package com.mycompany.a3;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;
import com.codename1.ui.geom.Rectangle;

public class Pylon extends Fixed{
	
	//number that represents the pylon
	private int sequenceNumber;
	private boolean isSelected;
	private static int count = 0;
	
	//used to create random number range
	public static int randInt(int min, int max) {
	    Random rand = new Random();
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
	
	//initializes a pylon with a location, color, and sequence number
	public Pylon(float x, float y, int color, int seqNum){
		setLocation(x,y);
		super.setColor(color);
		setSequenceNumber(seqNum);
		super.setSize(100);
		increment();
	}
	
	
	//gets the seq number
	public int getSequenceNumber() {
		return sequenceNumber;
	}
	
	//sets the seq number
	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	
	//will not be able to change color after created
	public void setColor(){
		//empty to not be able to change color
	}
	
	//will not be able to change size after created
	public void setSize(){
		//empty to avoid setting size
	}
	
	private void increment(){
		count++;
	}
	
	public static void decrement(){
		count--;
	}
	
	public static int getCount(){
		return count;
	}
	
	//overides tostring to pylons attributes
	@Override
	public String toString(){
		return "Pylon: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())+"]" 
				+ " seqNum=" + sequenceNumber; 
	}

	//helps selection
	@Override
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;

	}
	
	@Override
	public boolean isSelected() {
		return isSelected;
	}

	@Override
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
		int px = pPtrRelPrnt.getX();
		int py = pPtrRelPrnt.getY();
		int locX = (int) (pCmpRelPrnt.getX() + getX());
		int locY = (int) (pCmpRelPrnt.getY() + getY());
		if ((px >= locX) && (px <= locX + getSize()) && (py >= locY) && (py <= locY + getSize())) {
			return true;
		} else {
			return false;
		}
	}

	//draws pylon
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(getColor());
		int xLoc = (int) (pCmpRelPrnt.getX() + getX());
		int yLoc = (int) (pCmpRelPrnt.getY() + getY());
		int[] xPts = {xLoc, xLoc + getSize()/2, xLoc + getSize()};
		int[] yPts = {yLoc, yLoc + getSize(), yLoc};

		
		if(isSelected()){
			g.drawPolygon(xPts, yPts, 3);
		}
		else{
			g.drawPolygon(xPts, yPts, 3);
			g.fillPolygon(xPts, yPts, 3);
		}
		g.setColor(ColorUtil.BLACK);
		g.drawString("Pylon #"+this.getSequenceNumber(), xLoc, yLoc+getSize());
	}
	
	public int getLeft() {
		return (int)(this.getX()-(getSize()));
	}

	public int getRight() {
		return (int)(this.getX()+(getSize()));
	}

	public int getTop() {
		return (int)(this.getY()+(getSize()));
	}

	public int getBottom() {
		return (int) (this.getY()-(getSize()));
	}
	
	@Override
	public String getType() {
		return "PYLON";
	}

}
