package com.mycompany.a3;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
//import com.codename1.charts.models.Point;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Graphics;
import com.codename1.ui.Label;
import com.codename1.ui.geom.Point;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer{
	
	private GameWorld gw;
	private Game game;
	private Pylon py;

	
	public MapView(GameWorld gw){
		this.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		this.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.BLUE));
		this.gw = gw;

	}

	//displays dialog when game is over
	public void update(Observable observable, Object data) {
		gw = (GameWorld) observable;
		if(gw.getLives() <= 0){
			if (Dialog.show("Game Over", "Highest Pylon: " +gw.getLastPylon(), "Exit", null)){
				System.exit(0);
			}
		}
		/*GameObjectCollection objectCollection = gw.getObjects();
		IIterator theElements = objectCollection.getIterator();
		while (theElements.hasNext()) {
			GameObject go = (GameObject) theElements.next();
			if(go instanceof NonPlayerCar){
				this.npcLabel.setText("NPC");
			}
			else if(go instanceof Car){
				this.pcLabel.setText("Player");
			}
			else if(go instanceof FuelCan){
				this.fcLabel.setText("Fuel");
			}
			else if(go instanceof Bird){
				this.bLabel.setText("Bird");
			}
			else if(go instanceof Pylon){
				this.pyLabel.setText("Pylon"+ py.getSequenceNumber());
			}
		}*/
		this.repaint();
	}
	
	@Override
	public void paint(Graphics g) {
		// Iterate through each game object and draw them, Dogs = circle, Cats =
		// Triangle, Net = Square
		super.paint(g);
		GameObjectCollection objectCollection = gw.getObjects();
		IIterator theElements = objectCollection.getIterator();
		Point pCmpRelPrnt = new Point(getX(), getY());
		while (theElements.hasNext()) {
			GameObject go = (GameObject) theElements.next();
			go.draw(g, pCmpRelPrnt);
			
		}
	}
	
	@Override
	public void pointerPressed(int x, int y) {
		x = x - getParent().getAbsoluteX();
		y = y - getParent().getAbsoluteY();
		Point pPtrRelPrnt = new Point(x, y);
		Point pCmpRelPrnt = new Point(getX(), getY());
		//System.out.println(pPtrRelPrnt.getX());
		//System.out.println(pPtrRelPrnt.getY());
		GameObjectCollection objectCollection = gw.getObjects();
		IIterator theElements = objectCollection.getIterator();
		while (theElements.hasNext()) {
			GameObject go = (GameObject) theElements.next();
			if (go instanceof ISelectable) {//allows for selection
				if (((ISelectable) go).contains(pPtrRelPrnt, pCmpRelPrnt) && !Game.isPause()) {
					((ISelectable) go).setSelected(true);
					
				} 
				else if(((ISelectable) go).isSelected() && !Game.isPosition()){//for position changing when paused
					go.setLocation(pPtrRelPrnt.getX()-this.getAbsoluteX()-go.getSize()/2, pPtrRelPrnt.getY()-this.getAbsoluteY()+go.getSize()/2);
					Game.setPosition(true);
				}
				else {
					((ISelectable) go).setSelected(false);
				}
				/*if(((ISelectable) go).isSelected()){
					if(Game.isPosition()){
						go.setLoc(pPtrRelPrnt, pCmpRelPrnt);
						Game.setPosition(false);
					}
				}*/
				
				
			}
		
			
		}
		
		
		//iPx = x;
		//iPy = y;
		repaint();
	}


	public int getXloc() {
		return this.getX();
	}

	public int getYloc() {
		return this.getY();
	}




}
