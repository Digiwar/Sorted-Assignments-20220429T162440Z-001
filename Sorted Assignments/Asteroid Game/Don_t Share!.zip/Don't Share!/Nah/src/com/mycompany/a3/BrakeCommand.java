package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class BrakeCommand extends Command{

	private GameWorld gw = new GameWorld();
	public BrakeCommand() {
		super("Brake");
	}
	
	//command to brake player
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.brakePlayer();
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
