package com.mycompany.a3;

public interface ICarStrategy {

	public void applyStrategy();
	
}
