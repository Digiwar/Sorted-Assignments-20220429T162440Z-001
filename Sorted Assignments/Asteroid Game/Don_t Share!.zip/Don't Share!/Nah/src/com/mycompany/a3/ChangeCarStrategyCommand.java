package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class ChangeCarStrategyCommand extends Command{

	private GameWorld gw = new GameWorld();
	public ChangeCarStrategyCommand() {
		super("ChangeCarStrategy");
	}
	
	//cmd to change strategies
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.changeNPCStrategies();
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
