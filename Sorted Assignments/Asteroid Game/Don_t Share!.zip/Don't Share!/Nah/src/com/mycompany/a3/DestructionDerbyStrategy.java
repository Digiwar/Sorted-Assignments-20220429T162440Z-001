package com.mycompany.a3;

import com.codename1.util.MathUtil;

public class DestructionDerbyStrategy implements ICarStrategy{
	private Car myCar;
	private Car targetCar;
	
	public DestructionDerbyStrategy(NonPlayerCar thisCar, Car target){
		myCar = thisCar;
		targetCar = target;
	}
	
	public String toString(){
		return "DestructionDerby";
	}
	
	public void applyStrategy(){
		// code sets npc towards the given cars heading
		float dx, dy;
		
		dx = targetCar.getX() - myCar.getX();
		dy = targetCar.getY() - myCar.getY();

		int angle = (int)Math.toDegrees( MathUtil.atan2(dx, dy) );
		myCar.setHeading( angle );
	}
	
	
}
