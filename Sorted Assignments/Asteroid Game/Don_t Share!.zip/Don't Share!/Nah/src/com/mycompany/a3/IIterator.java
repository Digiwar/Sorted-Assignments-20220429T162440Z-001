package com.mycompany.a3;

public interface IIterator {
	
	//checks to see if the collection have a next element
	public boolean hasNext();
	
	// return the next object in the collection
	public Object next();

}
