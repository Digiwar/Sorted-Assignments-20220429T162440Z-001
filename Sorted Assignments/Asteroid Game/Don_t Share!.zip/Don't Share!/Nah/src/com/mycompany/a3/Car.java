package com.mycompany.a3;

import java.util.ArrayList;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Label;
import com.codename1.ui.geom.Point;
import com.codename1.ui.geom.Rectangle;

public class Car extends Movable implements ISteerable, ICollider{
	
	private int steeringDirection;
	private float maximumSpeed;
	private double fuelLevel;
	private double fuelConsumptionRate;
	private int damageLevel;
	private int lastPylonReached;
	private int maxDamage;
	private final int MAXIMUM_TURN_RADIUS = 40;
	private ArrayList<ICollider> collisionList = new ArrayList<ICollider>();

	
	//creates a car with set location heading speed and color
	public Car(float x, float y, int heading, int speed, int color){
		super.setSize(80);
		this.setSteeringDirection(0);
		this.setMaximumSpeed(50);
		this.setDamageLevel(0);
		this.setLocation(x, y);
		this.setHeading(heading);
		super.setSpeed(speed);
		super.setColor(color);
		this.setmaxDamage(10);
		this.setFuelLevel(25);
	}
	
	
	//modifies steering direction 5 degrees to the right
	public void steerRight() {
		
		if( steeringDirection < (MAXIMUM_TURN_RADIUS - 4) ){
			
			steeringDirection += 5;
			this.setHeading(this.getHeading() + this.steeringDirection);
			
		}
		
	}

	//modifies steering direction 5 degrees to the left
	public void steerLEft() {
		
		if( steeringDirection > (4 - MAXIMUM_TURN_RADIUS) ){
			
			steeringDirection -= 5;
			this.setHeading(this.getHeading() + this.steeringDirection);
			
		}
		
	}
	
	//moves the car
	@Override
	public void move() {
		
		useFuel((.02*10)/10);
		int angle = 90 - this.getHeading();
		float deltaX = ( ((float)Math.cos( Math.toRadians(angle) )) * this.getSpeed());
		float deltaY = ( ((float)Math.sin( Math.toRadians(angle) )) * this.getSpeed());
		float newX = this.getX() + deltaX;
		float newY = this.getY() + deltaY;
		super.setLocation( newX, newY );
		checkSpeed();		
		this.setHeading( this.getHeading() + steeringDirection );
		
		//if (this.getHeading() > 360){			
		//	this.setHeading(this.getHeading() - 360);
		//}
		
		//else if (this.getHeading() < -360){
		//	this.setHeading(this.getHeading() + 360);
		//}
		this.setSteeringDirection(0);
	}
	
	

	//gets the steer direction
	public int getSteeringDirection() {
		
		return steeringDirection;
		
	}

	//set the steer direction
	public void setSteeringDirection(int steeringDirection) {
		
		this.steeringDirection = steeringDirection;
		
	}

	//gets the max speed
	public float getMaximumSpeed() {
		
		return maximumSpeed;
		
	}

	//sets the max speed
	public void setMaximumSpeed(int maximumSpeed) {
		
		this.maximumSpeed = maximumSpeed;
		
	}

	//gets the fuel level
	public double getFuelLevel() {
		
		return fuelLevel;
		
	}
	
    // sets the fuel level
	public void setFuelLevel(double fuelLevel) {
		
		this.fuelLevel = fuelLevel;
		
	}

	//gets how much fuel the car uses
	public double getFuelConsumptionRate() {
		
		return fuelConsumptionRate;
		
	}

	//sets how much fuel the car loses
	public void setFuelConsumptionRate(double fuelConsumptionRate) {
		
		this.fuelConsumptionRate = fuelConsumptionRate;
		
	}

	//gets the damage level of the car
	public int getDamageLevel() {
		
		return damageLevel;
		
	}

	//sets the dmg level of the car
	public void setDamageLevel(int damageLevel) {
		
		this.damageLevel = damageLevel;
		
	}

	//gets the last pylon the car reached
	public int getLastPylonReached() {
		
		return lastPylonReached;
		
	}

	//sets the last pylon that the car reached
	public void setLastPylonReached(int lastPylonReached) {
		
		this.lastPylonReached = lastPylonReached;
		
	}

	//gets the max dmg
	public int getmaxDamage() {
		
		return maxDamage;
		
	}
	
	public void setmaxDamage(int i){
		
		this.maxDamage = i;
		
	}

	//gets the max turn radius
	public int getMAXIMUM_TURN_RADIUS() {
		
		return MAXIMUM_TURN_RADIUS;
		
	}
	
	//prevents car from changing color
	public void setColor(){
		
	}
	
	//prevents the car from changing its size
	public void setSize(){
		
	}
	
	//adjust the speed of the car according to its dmg and fuel level
	public void checkSpeed(){
		
		//if( this.getSpeed() > ( maximumSpeed * ( (maxDamage - damageLevel) / maxDamage))){
		//	setSpeed((getSpeed()*(maxDamage-damageLevel)/ maxDamage));
		//}
		
		if(this.getFuelLevel() == 0){
			setSpeed(0);
		}
	
	}
	
	
	//reduces fuel from car
	private void useFuel(double fuel){
		
		if (this.getFuelLevel() > 0){
			fuelLevel -= fuel;
		}
		
		if (this.getFuelLevel() < 0){
			fuelLevel = 0;
		}
		
	}
	
	//adds speed to car
	public void accelerate(){
		
		float accel = (float) 3.0;
		//if( getSpeed() < (maximumSpeed * ((maxDamage - damageLevel)/maxDamage))){
		this.setSpeed( this.getSpeed() + (accel*(maxDamage-damageLevel)/ maxDamage));
		//}
		//this.setSpeed(accel);
	}
	
	//reduces speed from car
	public void brake(){
		
		if( getSpeed() > 0 ){
			setSpeed( getSpeed() - 3);
		}	
		
		if( getSpeed() < 0){
			setSpeed(0);
		}
		
	}
	
	//adds fuel to car
	public void addFuel(double Fuel){
		
		fuelLevel += Fuel;
		
	}
	
	//adds damage to car
	public void addDamage(int damage){
		
		damageLevel += damage;
		this.checkSpeed();
		
	}
	
	//resets the position of the car
	public void reset(float x, float y){
		this.setLocation(x, y);
		this.setSpeed(0);
		this.setHeading(0);
		this.setFuelLevel(25);
		this.setDamageLevel(0);
	}
	
	//Overrides to string to show car attributes
	@Override
	public String toString(){
		String carString = "Car: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())
				+"]" +" heading="+this.getHeading()+" speed="+this.getSpeed()
				+ " size=" + this.getSize()+ " maxSpeed="+this.getMaximumSpeed()+" steeringDirection="
				+this.getSteeringDirection()+ " fuelLevel="+this.getFuelLevel()+" damageLevel="+
				this.getDamageLevel();
		carString += " type= player";
		return carString;
	}

	//draws the car
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(getColor());
		int xLoc = (int) (pCmpRelPrnt.getX() + getX());
		int yLoc = (int) (pCmpRelPrnt.getY() + getY());
		g.drawArc(xLoc, yLoc, getSize(), getSize(), 0, 360);
		g.fillArc(xLoc, yLoc, getSize(), getSize(), 0, 360);
		
		g.setColor(ColorUtil.BLACK);
		g.drawString("Player", xLoc, yLoc+getSize());
		
	}

	//searches for collisions
	@Override
	public boolean collidesWith(GameObject otherObject) {
		if( getRight() <= otherObject.getX()+otherObject.getSize()/2 || getLeft() >= otherObject.getX()-otherObject.getSize()/2 )
			// no left/right overlap, return false
			return false;
		
		// there was left/right overlap, now check top/bottom
		if( otherObject.getY()+otherObject.getSize()/2 <= getBottom() || getTop() <= otherObject.getY()-otherObject.getSize()/2 )
			// no top/bottom overlap, return false
			return false;
		
		
		// there was overlap in both L/R and T/B, they are colliding
		return true;
	
	}

	//handles the collisions
	@Override
	public void handleCollision(GameObject otherObject, GameWorld gw) {
		if(otherObject instanceof NonPlayerCar){
			this.addDamage(2);
		}
		else if(otherObject instanceof Car){
			//this.addDamage(2);
		}
		else if(otherObject instanceof FuelCan){
			if(((FuelCan) otherObject).getCapacity()>0){
				gw.playerGetsFuelCan(this , (FuelCan) otherObject);
			}
		}
		else if(otherObject instanceof Bird){
			this.addDamage(1);
		}
		else if(otherObject instanceof Pylon){
			Pylon p = (Pylon)otherObject;
			if(p.getSequenceNumber() - getLastPylonReached() == 1){
				setLastPylonReached(p.getSequenceNumber());
			}
		}
	}
	
	//handles hitting a pylon
	public boolean hitPylon(int p){	
		
		// car cannot hit pylon outside the realm of total pylons
		if( p > Pylon.getCount() )
			return false;
		
		// car can only activate this pylon if it is
		// the one immediately after the last one they hit
		if( p == (this.lastPylonReached + 1) ){
			// update the player's pylon progress
			this.lastPylonReached = p;
			return true;
			}
		
		// player didn't hit the next valid pylon
		return false;
	}
	
	//attributes for collision checking
	public int getLeft() {
		return (int)(this.getX()-(getSize()));
	}

	public int getRight() {
		return (int)(this.getX()+(getSize()));
	}

	public int getTop() {
		return (int)(this.getY()+(getSize()));
	}

	public int getBottom() {
		return (int) (this.getY()-(getSize()));
	}
	//another way to determine obj
	@Override
	public String getType() {
		return "PLAYER";
	}
	
	//add to collision list
	public void addTo(ICollider obj) {
		collisionList.add(obj);
	}
	
	//remove from collision list
	public void removeFrom(ICollider obj) {
		collisionList.remove(obj);
	}
	
	//check to see if object is part of collision list
	public boolean checkList(ICollider obj) {
		if (collisionList.contains(obj)) {
			return true;
		} else {
			return false;
		}
	}
}
