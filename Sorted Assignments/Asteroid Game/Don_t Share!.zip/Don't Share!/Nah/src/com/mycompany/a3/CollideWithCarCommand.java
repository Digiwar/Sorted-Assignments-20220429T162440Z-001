package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class CollideWithCarCommand extends Command{

	private static CollideWithCarCommand theCarHitsCarCommand;
	private GameWorld gw = new GameWorld();
	public CollideWithCarCommand() {
		super("Collided with another car.");
	}
	
	public static CollideWithCarCommand getInstance(){
		if(theCarHitsCarCommand == null)
			theCarHitsCarCommand = new CollideWithCarCommand();
		return theCarHitsCarCommand;
	}
	
	//cmd to make player car hit
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.playerCarCollision();
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
