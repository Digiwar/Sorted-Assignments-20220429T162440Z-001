package com.mycompany.a3;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;
import com.codename1.ui.geom.Rectangle;

public class FuelCan extends Fixed{
	
	//how much fuel is in the can
	private int capacity;
	private boolean isSelected;
	
	//used to create random integers
	public static int randInt(int min, int max) {
	    Random rand = new Random();
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
	
	//create a fuel can with random location, capacity, but solid color
	public FuelCan(){
		setLocation((float)randInt(68,1700), (float)randInt(100,1100));
		setCapacity(randInt(5,25));
		setSize(this.capacity*3);
		super.setColor(ColorUtil.CYAN);
	}
	
	//overloads fuelcan to create with set location, color, capacity 
	public FuelCan(float x, float y, int color, int capacity){
		setLocation(x,y);
		super.setColor(color);
		setCapacity(capacity);
		setSize(capacity);
	}
	
	//getter for capacity
	public int getCapacity() {
		
		return capacity;
		
	}

	//setter for capacity
	public void setCapacity(int capacity) {
		
		this.capacity = capacity;
		
	}
	
	//overides tostring for fuelcan attributes
	@Override
	public String toString(){
		return "FuelCan: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())+"]" 
				+ " size=" + this.getCapacity();
	}

	//helps selecting
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;

	}
	
	public boolean isSelected() {
		return isSelected;
	}

	//checks to see if click is inside the object
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
		// TODO Auto-generated method stub
		int px = pPtrRelPrnt.getX();
		int py = pPtrRelPrnt.getY();
		int locX = (int) (pCmpRelPrnt.getX() + getX());
		int locY = (int) (pCmpRelPrnt.getY() + getY());
		if ((px >= locX) && (px <= locX + getSize()) && (py >= locY) && (py <= locY + getSize())) {
			return true;
		} else {
			return false;
		}
	}

	//draws the fuel cans
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(getColor());
		int xLoc = (int) pCmpRelPrnt.getX() + (int) getX();
		int yLoc = (int) pCmpRelPrnt.getY() + (int) getY();
		if(isSelected()){
			g.drawRect(xLoc, yLoc, getSize()/2, getSize()/2);
		} 
		else {
			g.drawRect(xLoc, yLoc, getSize()/2, getSize()/2);
			g.fillRect(xLoc, yLoc, getSize()/2, getSize()/2);
		}
		
		g.setColor(ColorUtil.BLACK);
		g.drawString("Fuel: "+this.getCapacity(), xLoc, yLoc+getSize());
	}
	
	//another way to determine type
	@Override
	public String getType() {
		return "FUEL";
	}
	
	//helps with collisions
	public int getLeft() {
		return (int)(this.getX()-(getSize()));
	}

	public int getRight() {
		return (int)(this.getX()+(getSize()));
	}

	public int getTop() {
		return (int)(this.getY()+(getSize()));
	}

	public int getBottom() {
		return (int) (this.getY()-(getSize()));
	}


	
}
