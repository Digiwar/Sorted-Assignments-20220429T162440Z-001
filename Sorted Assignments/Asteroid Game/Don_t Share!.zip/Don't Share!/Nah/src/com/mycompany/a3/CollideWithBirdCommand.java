package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class CollideWithBirdCommand extends Command{

	private static CollideWithBirdCommand theCarHitsBirdCommand;
	private GameWorld gw = new GameWorld();
	public CollideWithBirdCommand() {
		super("Collided with a bird.");
	}
	
	public static CollideWithBirdCommand getInstance(){
		if(theCarHitsBirdCommand == null)
			theCarHitsBirdCommand = new CollideWithBirdCommand();
		return theCarHitsBirdCommand;
	}
	
	//cmd to make bird collision
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.playerBirdCollision();
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
