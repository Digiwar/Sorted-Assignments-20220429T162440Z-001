package com.mycompany.a3;


import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.geom.Point;

public class PositionCommand extends Command {

	private Game game;
	private boolean toggle;
	private GameWorld gw = new GameWorld();
	private static boolean clicked = false;
	public PositionCommand() {
		super("Position");
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Game.setPosition(false);
		/*toggle = !toggle;
		if (toggle) {
			game.setNoPos(false);
			game.setPosition(false);
			game.posBtn.setText("Cancel");
		} else {
			game.setNoPos(true);
			game.setPosition(true);
			game.posBtn.setText("Position");
		}*/
	}
	
	public void setTarget(Game game) {
		this.game = game;

	}

	

	public static boolean isClicked() {
		return clicked;
	}

	public static void setClicked(boolean clicked) {
		PositionCommand.clicked = clicked;
	}
	
}