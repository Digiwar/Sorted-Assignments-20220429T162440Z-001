package com.mycompany.a3;
import java.lang.Math;
import java.util.Vector;

import com.codename1.util.MathUtil;

public class RaceCarStrategy implements ICarStrategy{

	private Car npcCar;
	private GameWorld npcGW;
	
	public RaceCarStrategy(Car thisCar, GameWorld gw){
		npcCar = thisCar;
		npcGW = gw;
	}
	
	public String toString(){
		return "Race Strategy";
	}
	
	public void applyStrategy(){
		
		int nextPylon = npcCar.getLastPylonReached() + 1;

		if( nextPylon > Pylon.getCount() )
			nextPylon = Pylon.getCount();
		
		float pX = 0, 
			  pY = 0;

		IIterator anIterator = npcGW.getObjects().getIterator();
		
		// setup a placeholder object
		Object currentObj = new Object();

		while( anIterator.hasNext() ){
			currentObj = anIterator.next();
			if(currentObj instanceof Pylon)
				if( ((Pylon)currentObj).getSequenceNumber() == nextPylon ){
					// found the next pylon they need to get to, save coordinates
					pX = ((Pylon)currentObj).getX();
					pY = ((Pylon)currentObj).getY();
				}
		}
		
		// change in x and y
		float dx, dy;
		
		// calculate the change
		dx = pX - npcCar.getX();
		dy = pY - npcCar.getY();
		
		// awesome, atan2 handles all the hard parts of arctan calculations
		int angle = (int)Math.toDegrees( MathUtil.atan2( dx, dy) );
		
		npcCar.setHeading( angle );
	}
	
	
}


