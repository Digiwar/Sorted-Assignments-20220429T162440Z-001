package com.mycompany.a3;

import java.util.ArrayList;
import java.util.Vector;

import com.codename1.ui.geom.Point;

public abstract class GameObject implements IDrawable{
	
	private Vector<Float> location;
	private Vector<Point> loc;
	private ArrayList<GameObject> collisionList = new ArrayList<GameObject>();
	private int color;
	private int size;
	private int collideTime;
	
	//sets up each game object to have a 2 point location
	public GameObject(){
		location = new Vector<Float>();
		location.setSize(2);
	}
	
	//returns size of object
	public int getSize(){
		return size;
	}
	
	//returns color of object
	public int getColor(){
		return color;
	}
	
	//sets the color of object
	public void setColor(int newColor) {
		color = newColor;
	}
	
	//sets the size of the object
	public void setSize(int newSize) { 
		size = newSize;
	}
	
	//returns x location of object
	public float getX() {
		return location.get(0); //contains the x coordinate
	}
	
	//returns y location of object
	public float getY() {
		return location.get(1); //contains the y coordinate
	}
	
	//sets both the x and y location of object in same call
	public void setLocation(float x, float y) {
		location.set(0, x); //at 0, saves X coordinate
		location.set(1, y); //at 1, saves Y coordinate
	} 
	
	//gets the location with 2 points
	public Vector<Float> getLocation(){
		return location;
	}
	
	//rounds the location values
	public String toString() {
		return Math.round(getX() * 10.0) / 10.0 + ", " + Math.round(getY() * 10.0) / 10.0; 
		//used this formula to only get tenths place
	}
	
	//Returns the collision time
	public int getCollideTick() {
		return collideTime;
	}
			
	//Sets the collision time for the game object
	public void setCollideTime(int currentTime) {
		collideTime = currentTime;
	}

	//dont even use these anymore
	public void addTo(GameObject obj) {
		collisionList.add(obj);
	}
	
	public void removeFrom(GameObject obj) {
		collisionList.remove(obj);
	}
	
	public boolean checkList(GameObject obj) {
		if (collisionList.contains(obj)) {
			return true;
		} else {
			return false;
		}
	}

	public String getType() {
		return null;
	}

	public void setLoc(Point p, Point q) {
		loc.set(0, p); //at 0, saves X coordinate
		loc.set(1, q);
	}

	
	
}
