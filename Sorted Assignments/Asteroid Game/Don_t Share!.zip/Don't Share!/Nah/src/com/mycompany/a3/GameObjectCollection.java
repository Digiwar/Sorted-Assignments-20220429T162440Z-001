package com.mycompany.a3;

import java.util.Vector;

import com.mycompany.a3.ICollection;


public class GameObjectCollection implements ICollection {


	private Vector<Object> theCollection;
	

	
	public GameObjectCollection(){
		theCollection = new Vector<Object>();
	}
	
	//add to collection
	public void add(Object newObject) {
		theCollection.addElement(newObject);
	}

	//remove from collection
	public void remove(Object newObject) {
		theCollection.removeElement(newObject);
	}
	
	public IIterator getIterator(){
		return new GameObjectIterator();
	}

	//class to iterate through objects
	private class GameObjectIterator implements IIterator {
		
		// index for
		private int currObjIndex;
		

		// construct an iterator, and initialize index to -1
		public GameObjectIterator(){
			currObjIndex = -1;
		}
		
		// are there more objects in the collection?
		public boolean hasNext(){
			
			// are there any at all?
			if(theCollection.size() < 1){
				return false;
			}
			
			// are there any after the last one we returned?
			if(currObjIndex == theCollection.size() - 1 ){
				return false;
			}			
			
			return true;
		}

		// return the next object in the collection
		public Object next() {
			currObjIndex++;
			return(theCollection.elementAt(currObjIndex));
		}
	}
	
	public Object[] toArray(){
		return theCollection.toArray();
	}
	
	public int getSize(){
		return theCollection.size();
	}
	

}
