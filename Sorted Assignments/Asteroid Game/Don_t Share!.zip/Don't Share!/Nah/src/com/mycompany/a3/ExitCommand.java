package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;

public class ExitCommand extends Command{

	@SuppressWarnings("unused")
	private GameWorld gw = new GameWorld();
	public ExitCommand() {
		super("Exit");
	}
	
	//cmd to check if user wanted to exit
	@Override
	public void actionPerformed(ActionEvent e) {
		if(!Dialog.show("Exit Confirmation", "Are you sure you want to quit?", "No", "Yes")) {	
			//Prompts the user to quit or not
			System.exit(0);
		}
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
