package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class AccelerateCommand extends Command{
	
	private GameWorld gw = new GameWorld();
	public AccelerateCommand() {
		super("Accelerate");
	}
	
	//command to accelerate player
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.acceleratePlayer();
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}

}
