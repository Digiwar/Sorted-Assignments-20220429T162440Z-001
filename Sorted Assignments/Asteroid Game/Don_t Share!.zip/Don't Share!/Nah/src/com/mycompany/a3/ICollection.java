package com.mycompany.a3;

public interface ICollection {
	//add objects
	public void add(Object newObject);
	
	//remove objects
	public void remove(Object newObject);
}
