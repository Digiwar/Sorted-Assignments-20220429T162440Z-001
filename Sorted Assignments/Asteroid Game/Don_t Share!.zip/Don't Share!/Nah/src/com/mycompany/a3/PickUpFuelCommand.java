package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class PickUpFuelCommand extends Command{

	private static PickUpFuelCommand theCarGetsFuelCommand;
	private GameWorld gw = new GameWorld();
	public PickUpFuelCommand() {
		super("Picked up some Fuel.");
	}
	
	//cmd to pick up fuel
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.playerGetsFuelCan(null, null);
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
	public static PickUpFuelCommand getInstance(){
		if(theCarGetsFuelCommand == null)
			theCarGetsFuelCommand = new PickUpFuelCommand();
		return theCarGetsFuelCommand;
	}
	
}
