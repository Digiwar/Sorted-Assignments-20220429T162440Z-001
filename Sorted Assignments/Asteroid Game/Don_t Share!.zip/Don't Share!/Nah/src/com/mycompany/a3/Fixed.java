package com.mycompany.a3;

//class for fixed objects to extend from
public abstract class Fixed extends GameObject implements ISelectable{
	
	
	public void setLocation(){
		//empty so it cannot change location
	}
	
	

}
