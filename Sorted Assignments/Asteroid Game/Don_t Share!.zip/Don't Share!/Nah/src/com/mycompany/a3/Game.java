package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Toolbar;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.util.UITimer;
import com.mycompany.a3.GameWorld;

public class Game extends Form implements Runnable{
	
	private GameWorld gw;
	private MapView mv;
	private ScoreView sv;
	private UITimer timer;
	private static boolean control = true;
	private static boolean pause = true;
	private static boolean position = true;
	private static boolean noPos = true;
	
	//adding buttons
	Button switchStratBtn = new Button("Switch Strategy");
	Button accelerateBtn = new Button("Accelerate");
	Button brakeBtn = new Button("Brake");
	Button rightBtn = new Button("Right");
	Button leftBtn = new Button("Left");
	Button exitBtn = new Button("Exit");
	Button npcCollideBtn = new Button("Collide With NPC");
	Button pylonCollideBtn = new Button("Collide With Pylon");
	Button birdCollideBtn = new Button("Collide With Bird");
	Button getFuelBtn = new Button("Pickup Fuel Can");
	Button tickBtn = new Button("Tick");
	Button pauseBtn = new Button("Pause");
	Button posBtn = new Button("Position");
	
	//stylizer for the buttons
	private void buttonStyle(Button b){
		b.getUnselectedStyle().setBgTransparency(255);
		b.getUnselectedStyle().setFgColor(ColorUtil.WHITE);
		b.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
		b.getAllStyles().setPadding(Component.TOP, 5);
		b.getAllStyles().setPadding(Component.BOTTOM, 5);
	}
	
	AboutCommand cmdAbout = new AboutCommand();
	AccelerateCommand cmdAccelerate = new AccelerateCommand();
	BrakeCommand cmdBrake = new BrakeCommand();
	ChangeCarStrategyCommand cmdChangeStrat = new ChangeCarStrategyCommand();
	CollideWithBirdCommand cmdBird = new CollideWithBirdCommand();
	CollideWithCarCommand cmdCar = new CollideWithCarCommand();
	CollideWithPylonCommand cmdPylon = new CollideWithPylonCommand();
	PickUpFuelCommand cmdFuel = new PickUpFuelCommand();
	RightCommand cmdRight = new RightCommand();
	LeftCommand cmdLeft = new LeftCommand();
	SoundCommand cmdSound = new SoundCommand();
	TickCommand cmdTick = new TickCommand();
	ExitCommand cmdExit = new ExitCommand();
	HelpCommand cmdHelp = new HelpCommand();
	MapCommand cmdMap = new MapCommand();
	PauseCommand cmdPause = new PauseCommand();
	PositionCommand cmdPosition = new PositionCommand();
	
	public Game() {
		this.setLayout(new BorderLayout());
		this.setTitle("Race Car Game");
		gw = new GameWorld(); //initializes game world
		gw.init(); //initializes game objects
		mv = new MapView(gw);
		sv = new ScoreView();
		gw.addObserver(mv);
		gw.addObserver(sv);
		gw.setChange();
		this.add(BorderLayout.NORTH, sv);
		this.add(BorderLayout.CENTER, mv);
		timer = new UITimer(this); //Timer
		timer.schedule(20, true, this);
		
		//setting targets for commands
		cmdAbout.setTarget(gw);
		cmdAccelerate.setTarget(gw);
		cmdBrake.setTarget(gw);
		cmdChangeStrat.setTarget(gw);
		cmdBird.setTarget(gw);
		cmdCar.setTarget(gw);
		cmdPylon.setTarget(gw);
		cmdFuel.setTarget(gw);
		cmdRight.setTarget(gw);
		cmdLeft.setTarget(gw);
		cmdSound.setTarget(gw);
		cmdTick.setTarget(gw);
		cmdExit.setTarget(gw);
		cmdHelp.setTarget(gw);
		cmdMap.setTarget(gw);
		cmdPause.setTarget(this);
		cmdPosition.setTarget(this);
		
		//strategies to buttons
		switchStratBtn.setCommand(cmdChangeStrat);
		accelerateBtn.setCommand(cmdAccelerate);
		brakeBtn.setCommand(cmdBrake);
		rightBtn.setCommand(cmdRight);
		leftBtn.setCommand(cmdLeft);
		tickBtn.setCommand(cmdTick);
		exitBtn.setCommand(cmdExit);
		npcCollideBtn.setCommand(cmdCar);
		birdCollideBtn.setCommand(cmdBird);
		pylonCollideBtn.setCommand(cmdPylon);
		getFuelBtn.setCommand(cmdFuel);
		pauseBtn.setCommand(cmdPause);
		posBtn.setCommand(cmdPosition);
		
		//KeyListeners
		addKeyListener('a', cmdAccelerate);
		addKeyListener('b', cmdBrake);
		addKeyListener('l', cmdLeft);
		addKeyListener('r', cmdRight);
		//addKeyListener('c', cmdCar);
		//addKeyListener('f', cmdFuel);
		//addKeyListener('t', cmdTick);
		addKeyListener('e', cmdExit);
		addKeyListener('m', cmdMap);

		
		//Toolbar
		Toolbar toolbar = new Toolbar();
		this.setToolbar(toolbar);
		CheckBox cb = new CheckBox("Sound");
		cb.setCommand(cmdSound);
		cb.getUnselectedStyle().setBgTransparency(255);
		cb.getUnselectedStyle().setBgColor(ColorUtil.LTGRAY);
		cmdSound.putClientProperty("SideComponent", cb);
		toolbar.addCommandToSideMenu(cmdSound);
		toolbar.addCommandToSideMenu(cmdAccelerate);
		toolbar.addCommandToSideMenu(cmdAbout);
		toolbar.addCommandToSideMenu(cmdExit);
		toolbar.addCommandToRightBar(cmdHelp);

		//Left Container
		Container leftContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		leftContainer.getAllStyles().setPadding(Component.TOP, 50);
		leftContainer.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLUE));
		buttonStyle(switchStratBtn); //switchStratBtn Button
		leftContainer.add(switchStratBtn);
		buttonStyle(accelerateBtn); //accel button
		leftContainer.add(accelerateBtn);
		buttonStyle(brakeBtn); //brake button
		leftContainer.add(brakeBtn);
		buttonStyle(rightBtn); //right Button
		leftContainer.add(rightBtn);
		buttonStyle(leftBtn); //Left Button
		leftContainer.add(leftBtn);
		buttonStyle(exitBtn);
		leftContainer.add(exitBtn);
		add(BorderLayout.WEST, leftContainer);
		
		Container bottomContainer = new Container(new FlowLayout(Component.CENTER));
		bottomContainer.getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLUE));
		//buttonStyle(npcCollideBtn); //collide with npc Button
		//bottomContainer.add(npcCollideBtn);
		//buttonStyle(pylonCollideBtn); //collide with pylon button
		//bottomContainer.add(pylonCollideBtn);
		//buttonStyle(birdCollideBtn); //collide with bird button
		//bottomContainer.add(birdCollideBtn);
		//buttonStyle(getFuelBtn); //get fuel Button
		//bottomContainer.add(getFuelBtn);
		//buttonStyle(tickBtn); //tick Button
		//bottomContainer.add(tickBtn);
		buttonStyle(pauseBtn);
		bottomContainer.add(pauseBtn);
		buttonStyle(posBtn);
		bottomContainer.add(posBtn);
		posBtn.setEnabled(false);
		add(BorderLayout.SOUTH, bottomContainer);
				
				

				

		this.show();
		//play();
	}

	//get the game running
	@Override
	public void run() {
		Dimension dCmpSize = new Dimension (mv.getWidth(), mv.getHeight());
		gw.tick(dCmpSize);
	}
	
	//start game back up
	public void start() {
		timer.schedule(20, true, this);
	}

	//pause game
	public void cancel() {
		timer.cancel();
	}
	
	//changes what is availible to use depending on game pause
	public void control(boolean control) {
		if (!control) {
			switchStratBtn.setEnabled(false);
			accelerateBtn.setEnabled(false);
			brakeBtn.setEnabled(false);
			rightBtn.setEnabled(false);
			leftBtn.setEnabled(false);
			exitBtn.setEnabled(false);
			npcCollideBtn.setEnabled(false);
			pylonCollideBtn.setEnabled(false);
			birdCollideBtn.setEnabled(false);
			getFuelBtn.setEnabled(false);
			tickBtn.setEnabled(false);
			pauseBtn.setEnabled(true);
			posBtn.setEnabled(true);
			cmdAbout.setEnabled(false);
			cmdAccelerate.setEnabled(false);
			cmdBrake.setEnabled(false);
			cmdChangeStrat.setEnabled(false);
			cmdBird.setEnabled(false);
			cmdCar.setEnabled(false);
			cmdPylon.setEnabled(false);
			cmdFuel.setEnabled(false);
			cmdRight.setEnabled(false);
			cmdLeft.setEnabled(false);
			cmdSound.setEnabled(false);
			cmdTick.setEnabled(false);
			cmdExit.setEnabled(true);
			cmdHelp.setEnabled(false);
			cmdMap.setEnabled(false);
			cmdPause.setEnabled(false);	
			cmdPosition.setEnabled(true);
			removeKeyListener('a', cmdAccelerate);
			removeKeyListener('b', cmdBrake);
			removeKeyListener('l', cmdLeft);
			removeKeyListener('r', cmdRight);
		} 
		else {
			addKeyListener('a', cmdAccelerate);
			addKeyListener('b', cmdBrake);
			addKeyListener('l', cmdLeft);
			addKeyListener('r', cmdRight);
			switchStratBtn.setEnabled(true);
			accelerateBtn.setEnabled(true);
			brakeBtn.setEnabled(true);
			rightBtn.setEnabled(true);
			leftBtn.setEnabled(true);
			exitBtn.setEnabled(true);
			npcCollideBtn.setEnabled(true);
			pylonCollideBtn.setEnabled(true);
			birdCollideBtn.setEnabled(true);
			getFuelBtn.setEnabled(true);
			tickBtn.setEnabled(true);
			pauseBtn.setEnabled(true);
			posBtn.setEnabled(false);
			cmdAbout.setEnabled(true);
			cmdAccelerate.setEnabled(true);
			cmdBrake.setEnabled(true);
			cmdChangeStrat.setEnabled(true);
			cmdBird.setEnabled(true);
			cmdCar.setEnabled(true);
			cmdPylon.setEnabled(true);
			cmdFuel.setEnabled(true);
			cmdRight.setEnabled(true);
			cmdLeft.setEnabled(true);
			cmdSound.setEnabled(true);
			cmdTick.setEnabled(true);
			cmdExit.setEnabled(true);
			cmdHelp.setEnabled(true);
			cmdMap.setEnabled(true);
			cmdPause.setEnabled(true);
			cmdPosition.setEnabled(false);	
			
		}
	}
	//bools to help with toggling
	public static boolean isControl() {
		return control;
	}

	public void setControl(boolean control) {
		this.control = control;
	}

	public static boolean isPause() {
		return pause;
	}

	public static void setPause(boolean pause) {
		Game.pause = pause;
	}

	public static boolean isPosition() {
		return position;
	}

	public static void setPosition(boolean position) {
		Game.position = position;
	}

	public boolean isNoPos() {
		return noPos;
	}

	public void setNoPos(boolean noPos) {
		this.noPos = noPos;
	}
	
	/*private void play() { //method to generate gui and input as well as accept input for game commands
		 Label myLabel=new Label("Enter a Command:");
		 this.addComponent(myLabel);
		 final TextField myTextField=new TextField();
		 this.addComponent(myTextField);
		 this.show();
		 myTextField.addActionListener(new ActionListener<ActionEvent>() {
		 public void actionPerformed(ActionEvent evt) {
			 String sCommand=myTextField.getText().toString();
			 myTextField.clear();
			 if(sCommand.equals("")) {
				 System.out.println("You must enter a legal command.");
			 }
			 else {
				 switch (sCommand.charAt(0)) {
					 case 'a'://kinda, cant accel after getting hit
						 gw.acceleratePlayer();
						 System.out.println("car is accelerating.");
						 break;
					 case 'b'://brakes player car
						 gw.brakePlayer();
						 System.out.println("brakes are applied.");
						 break;
					 case 'l'://steers player left
						 gw.turnPlayerLeft();
						 System.out.println("steering to the left.");
						 break;
					 case 'r'://steers player right
						 gw.turnPlayerRight();
						 System.out.println("steering to the right.");
						 break;	 
					 case 'c'://pretends player gets hit by another car
						 gw.playerCarCollision();
						 System.out.println("oh no! you've collided with another car.");
						 break;
					 case '0'://numbers 0 - 9 will pretend player reaches that pylon if in consecutive order
						 gw.playerHitPylon(0);
						 System.out.println("you've reached pylon 0");
						 break;
					 case '1':
						 gw.playerHitPylon(1);
						 System.out.println("you've reached pylon 1");
						 break;
					 case '2':
						 gw.playerHitPylon(2);
						 System.out.println("you've reached pylon 2");
						 break;
					 case '3':
						 gw.playerHitPylon(3);
						 System.out.println("you've reached pylon 3");
						 break;
					 case '4':
						 gw.playerHitPylon(4);
						 System.out.println("you've reached pylon 4");
						 break;
					 case '5':
						 gw.playerHitPylon(5);
						 System.out.println("you've reached pylon 5");
						 break;
					 case '6':
						 gw.playerHitPylon(6);
						 System.out.println("you've reached pylon 6");
						 break;
					 case '7':
						 gw.playerHitPylon(7);
						 System.out.println("you've reached pylon 7");
						 break;
					 case '8':
						 gw.playerHitPylon(8);
						 System.out.println("you've reached pylon 8");
						 break;
					 case '9':
						 gw.playerHitPylon(9);
						 System.out.println("you've reached pylon 9");
						 break;	 
					 case 'f'://working with java.util.ConcurrentModificationException error, gives player fuel
						 gw.playerGetsFuelCan();
						 System.out.println("you've picked up some fuel");
						 break;
					 case 'g'://bird colides with player car
						 gw.playerBirdCollision();
						 System.out.println("some gunk dropped on you from the bird above");
						 break;
					 case 't'://advances the game clock
						 gw.tick();
						 System.out.println("advance clock");
						 break;
					 case 'd'://prints the state of the game
						 gw.getGameState();
						 break;
					 case 'm'://prints the map of objects
						 gw.map();
						 break;
					 case 'x'://works
						 System.out.println ("Are you sure you want to exit? Type 'Y' for yes, 'N' for no");
						 break;
					 case 'y'://works
						 System.exit(0);
						 break;
					 case 'n'://works
						 //Do nothing
						 break;
					 default:
						 System.out.println("You must enter a legal command.");
						 break;
				 } //switch
			 }
		 } } ); //addActionListener 	 
	 }*/

}

