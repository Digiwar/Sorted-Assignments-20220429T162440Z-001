package com.mycompany.a3;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.geom.Point;
import com.codename1.ui.geom.Rectangle;

public class Bird extends Movable{
	
	
	private int xMax;
	private int yMax;
	//heading, speed, color, size
	
	//creates a random bird with random heading, size, color, speed
	public Bird(){
		setLocation((float)randInt(0,1024), (float)randInt(0,768));
		super.setSize(randInt(40,80));
		super.setColor(ColorUtil.GREEN);
		setHeading(randInt(0,359));
		setSpeed(randInt(3,6));
	}

	//overloads Bird to create with set location, color, capacity 
	public Bird(float x, float y, int color, int size, int speed){
		setLocation(x,y);
		super.setColor(color);
		super.setSize(size);
		setHeading(randInt(0,359));
		setSpeed(speed);
	}
	
	//used to create random integers
	public static int randInt(int min, int max) {
		Random rand = new Random();
		int randomNum = rand.nextInt((max - min) + 1) + min;
		return randomNum;
	}
	
	//makes it so bird cant change color after being created
	public void setColor(){
		
	}

	//moves the bird a distance according to its heading and speed, also it it is at an edge it will turn until its no longer there
	/*@Override
	public void move() {
		
		int angle = 90 - this.getHeading();
		float deltaX = ( ((float)Math.cos( Math.toRadians(angle) )) * this.getSpeed());
		float deltaY = ( ((float)Math.sin( Math.toRadians(angle) )) * this.getSpeed());
		float newX = this.getX() + deltaX;
		float newY = this.getY() + deltaY;
		this.setLocation( newX, newY );
		int rando = randInt(1,2);
		
		if (rando == 1){
			this.setHeading(this.getHeading() + randInt(0,20));
		}
		
		else if (rando == 2){
			this.setHeading(this.getHeading() - randInt(0,20));
		}
		
		if (this.getHeading() > 360){
			this.setHeading( this.getHeading() - 360);
		}
		
		else if (this.getHeading() < -360){
			this.setHeading( this.getHeading() + 360);
		}
		
		//try to redirect the bird back onto the map, like a roomba
		if (newX <= 0 || newX >= 1024 || newY <= 0 || newY >= 768){
			this.setHeading(this.getHeading()+90);
		}
		
	}*/
	//moves birds within the dimension of the mapview
	@Override
	public void move(Dimension dCmpSize) {
		setxMax(dCmpSize.getWidth());
		setyMax(dCmpSize.getHeight());
		int angle = 90 - this.getHeading();
		float deltaX = ( ((float)Math.cos( Math.toRadians(angle) )) * this.getSpeed());
		float deltaY = ( ((float)Math.sin( Math.toRadians(angle) )) * this.getSpeed());
		float newX = this.getX() + deltaX;
		float newY = this.getY() + deltaY;
		this.setLocation( newX, newY );
		int rando = randInt(1,2);
		if (rando == 1){
			this.setHeading(this.getHeading() + randInt(0,20));
		}
		else if (rando == 2){
			this.setHeading(this.getHeading() - randInt(0,20));
		}
		//try to redirect the bird back onto the map, like a roomba
		if (newX <= 0 || newX >= this.getyMax() || newY <= 0 || newY >= this.getyMax()){
			this.setHeading(this.getHeading()-178);
		}
		this.checkHeading();
		
	}
	
	//corrects the heading if birds go over 360 or under 0
	protected void checkHeading() {	//Method for checking if direction exceed 359 or goes below 0
		if (this.getHeading() >= 360) {
			this.setHeading(this.getHeading()-360);
		} else if (this.getHeading() <= 0) {
			this.setHeading(this.getHeading()+360);
		}
	}
	
	public int getxMax() {
		return xMax;
	}

	public void setxMax(int xMax) {
		this.xMax = xMax;
	}

	public int getyMax() {
		return yMax;
	}

	public void setyMax(int yMax) {
		this.yMax = yMax;
	}
	
	//prevents bird from changing size after creation
	public void setSize(){
		
	}
	
	//overides tosting to display bird attributes
	@Override
	public String toString(){
		return "Bird: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())+"] heading="+this.getHeading()+", "
				+ "speed="+ this.getSpeed()+ ", size=" + this.getSize();
	}

	
	//draws the birdies and puts labels on them
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(getColor());
		int xLoc = (int) (pCmpRelPrnt.getX() + getX());
		int yLoc = (int) (pCmpRelPrnt.getY() + getY());
		int[] xPts = {xLoc, xLoc + getSize()/2, xLoc + getSize()};
		int[] yPts = {yLoc, yLoc + getSize(), yLoc};
		g.drawPolygon(xPts, yPts, 3);
		
		g.setColor(ColorUtil.BLACK);
		g.drawString("Bird", xLoc, yLoc+getSize());
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		
	}

	//sets up for collision detection
	public int getLeft() {
		return (int)(this.getX()-(getSize()/2));
	}

	public int getRight() {
		return (int)(this.getX()+(getSize()/2));
	}

	public int getTop() {
		return (int)(this.getY()+(getSize()/2));
	}

	public int getBottom() {
		return (int) (this.getY()-(getSize()/2));
	}

	//another way of checking if this object is a bird
	@Override
	public String getType() {
		return "BIRD";
	}

}
