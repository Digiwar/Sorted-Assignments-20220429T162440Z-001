package com.mycompany.a3;

//interface for steerable objects to implement
public interface ISteerable {
	
	//used to steer the player right
	public void steerRight();
	
	//used to steet the player left
	public void steerLEft();

}
