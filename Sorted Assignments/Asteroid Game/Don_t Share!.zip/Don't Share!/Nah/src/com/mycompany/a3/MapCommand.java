package com.mycompany.a3;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class MapCommand extends Command {

	private GameWorld gw = new GameWorld();
	public MapCommand() {
		super("Map");
	}
	
	//cmd to print map for testing
	@Override
	public void actionPerformed(ActionEvent e) {
		gw.map();
	}
	
	//points this action towards the gameworld
	public void setTarget(GameWorld gw) {
		this.gw = gw;
	}
	
}
