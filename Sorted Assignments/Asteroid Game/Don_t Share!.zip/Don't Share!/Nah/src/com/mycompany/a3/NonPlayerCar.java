package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.geom.Point;

public class NonPlayerCar extends Car{

	private ICarStrategy curStrategy;
	
	public NonPlayerCar(float x, float y, int heading, int speed, int color) {
		super(x, y, heading, speed, color);
		// TODO Auto-generated constructor stub
		setmaxDamage(1000000000);
		setFuelLevel(1000000000);
		setLastPylonReached(0);
	}
	
	//add strats to npc move
	public void move(){
		invokeStrategy();
		super.move();
	}

	// code for applying strategies from IStrategy interface
	public ICarStrategy getStrategy(){
		return curStrategy;
	}
	
	//set strat for npc
	public void setStrategy(ICarStrategy s){
		this.curStrategy = s;
	}
	
	//apply the strat to the npc
	public void invokeStrategy(){
		curStrategy.applyStrategy();
	}

	@Override
	public String toString(){
		String npcString = "Car: loc=" + Math.round(this.getX() * 10.0) / 10.0 + "," + Math.round(this.getY() * 10.0) / 10.0 + 
				" color=[ "+ColorUtil.red(getColor())+","+ColorUtil.green(getColor())+", "+ColorUtil.blue(getColor())
				+"]" +" heading="+this.getHeading()+" speed="+this.getSpeed()
				+ " size=" + this.getSize()+ " maxSpeed="+this.getMaximumSpeed()+" steeringDirection="
				+this.getSteeringDirection()+ " fuelLevel="+this.getFuelLevel()+" damageLevel="+
				this.getDamageLevel();
		npcString += " type= NPC strategy = " +curStrategy.toString();
		return npcString;
	}

	@Override
	public String getType() {
		return "BIRD";
	}
	
	//draws car
	@Override
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(getColor());
		int xLoc = (int) (pCmpRelPrnt.getX() + getX());
		int yLoc = (int) (pCmpRelPrnt.getY() + getY());
		g.drawArc(xLoc, yLoc, getSize(), getSize(), 0, 360);
		g.setColor(ColorUtil.BLACK);
		g.drawString("NPC", xLoc, yLoc+getSize());
	
	}
	
}
