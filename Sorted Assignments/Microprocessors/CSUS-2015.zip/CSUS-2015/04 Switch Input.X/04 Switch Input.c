
// PICkit 3 PIC18F45K20 Lesson 4 - Switch Inputs
//
/* This lesson shows one method to software de-bounce a switch input.
 * Pin RB5 is connected to the input switch and set as an input.  When 
 * monitoring this pin the program makes a call to a delay routine in 
 * order to "de-bounce" the switch.  De-bouncing is required to avoid 
 * counting each mechanical 'micro-bounce" of the switch as an input.
 * 
 * Each press rotates the LEDs on PORTD.
 * 
//
// *******************************************************************
// *    See the software license at the bottom of this file           *
// *******************************************************************/

/** C O N F I G U R A T I O N   B I T S ******************************/

#pragma config WDTEN = OFF, LVP = OFF, MCLRE = ON
#pragma config FOSC = INTIO67



/** I N C L U D E S **************************************************/
#include <xc.h>
#include "delays.h"


/** V A R I A B L E S *************************************************/

unsigned char LED_Display;  // 8-bit variable
unsigned char Switch_Count  ;

/** D E C L A R A T I O N S *******************************************/

void wait_for_SW1_press(void);


void main (void)
{
    LED_Display = 1;            // initialize variable
    TRISD = 0b00000000;     	// Turn PORTD output port to drive
                                // .. the LEDs
    ANSELH = 0x00;              // ensure all pins are digital Pins
    TRISBbits.TRISB0 = 1;       // Turn RB0 into an input pin for SW1
  while (1)
    {
       LATD = LED_Display;       // output LED_Display value to PORTD LEDs
       LED_Display <<= 1;        // rotate display by 1
        if (LED_Display == 0)
            LED_Display = 1;     // rotated bit out, so set bit 0

       wait_for_SW1_press();     // wait until SW1 is pressed and released
     }
}

   void wait_for_SW1_press(void)
   {  while( !PORTBbits.RB0) ;    // wait until SW1 is pushed down
       delay(2) ;                // delay for de-bounce
       while( PORTBbits.RB0) ;   // wait for release
      
   }
  
//******************************************************************************
//Software License Agreement                                         
//                                                                    
//The software supplied herewith by Microchip Technology             
//Incorporated (the "Company") is intended and supplied to you, the  
//Company�s customer, for use solely and exclusively on Microchip    
//products. The software is owned by the Company and/or its supplier,
//and is protected under applicable copyright laws. All rights are   
//reserved. Any use in violation of the foregoing restrictions may   
//subject the user to criminal sanctions under applicable laws, as   
//well as to civil liability for the breach of the terms and         
//conditions of this license.                                        
//                                                                    
//THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,  
//WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED  
//TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A       
//PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,  
//IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR         
//CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.       
// *******************************************************************