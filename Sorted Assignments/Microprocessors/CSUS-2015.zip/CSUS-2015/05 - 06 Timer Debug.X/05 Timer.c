
/* PIC18F45K20 PICkit 3 Debug Express Demo Board Lesson 5 - Timer
 
 * The program initializes the I/O ports and Timer 0.  No
 * software delay loop is used, when the time "rolls over" the 
 * TMR0IF bit in the INTCON register goes high.
 * 
 * The program polls TMR0IF in order to induce a delay in execution.  
 * 
 * Students may notice no de-bounce on the input switch is performed.
 * The program takes a snap-shot look at the swith to determine if a press
 * or release has occured.


// *******************************************************************
// *    See License agreement at the bottom of this file         *
// *******************************************************************/

/** C O N F I G U R A T I O N   B I T S ******************************/

#pragma config FOSC = INTIO67
#pragma config WDTEN = OFF, LVP = OFF, MCLRE = ON

/** I N C L U D E S **************************************************/
#include <xc.h>
//#include "delays.h"  // no longer being used.


/** V A R I A B L E S *************************************************/
   // declare statically allocated uinitialized variables
unsigned char LED_Display;  // 8-bit variable
unsigned char Direction ;
#define LEFT2RIGHT 1
#define RIGHT2LEFT 0

unsigned char SwitchPressed ;
#define TRUE 1
#define FALSE 0

/** D E C L A R A T I O N S *******************************************/


void main (void)
{
    Direction = LEFT2RIGHT;
    SwitchPressed = FALSE;
    LED_Display = 1;            // initialize  variable

    // Init I/O
    TRISD = 0b00000000;     	// PORTD bits 7:0 are all outputs (0)
	
    ANSELH = 0x00;              // AN8-12 are digital inputs (AN12 on RB0)
    TRISBbits.TRISB0 = 1;       // PORTB bit 0 (connected to switch) is input (1)

    // Init Timer
    INTCONbits.TMR0IF = 0;       // clear roll-over interrupt flag
    T0CON = 0b00001000;          // no prescale - increments every instruction clock
    //T0CON = 0b00000001;        // prescale 1:4 - four times the delay.
    TMR0H = 0;                   // clear timer - always write upper byte first
    TMR0L = 0;
    T0CONbits.TMR0ON = 1;        // start timer

    while (1)
    {

        if (Direction == LEFT2RIGHT)
        {
            LED_Display <<= 1;          // rotate display by 1 from 0 to 7
            if (LED_Display == 0)
                LED_Display = 1;        // rotated bit out, so set bit 0
        }
        if (Direction == RIGHT2LEFT)
        {
            LED_Display >>= 1;          // rotate display by 1 from 7 to 0
            if (LED_Display == 0)
                LED_Display = 0x80;     // rotated bit out, so set bit 7
        }

        LATD = LED_Display;         // output LED_Display value to PORTD LEDs

        do
        { // poll the switch while waiting for the timer to roll over.
            if (PORTBbits.RB0 == 1)
            { // look for switch released.
                SwitchPressed = FALSE;
            }
            else if (SwitchPressed == FALSE) // && (Switch_Pin == 0) due to if-else
            { // switch was just pressed
                SwitchPressed = TRUE;
                // change  direction
                if (Direction == LEFT2RIGHT)
                    Direction = RIGHT2LEFT;
                else
                    Direction = LEFT2RIGHT;
            }

        } while (INTCONbits.TMR0IF == 0);

        // Timer expired
        INTCONbits.TMR0IF = 0;          // Reset Timer flag

    }
	
}


//******************************************************************************
//Software License Agreement                                         
//                                                                    
//The software supplied herewith by Microchip Technology             
//Incorporated (the "Company") is intended and supplied to you, the  
//Company�s customer, for use solely and exclusively on Microchip    
//products. The software is owned by the Company and/or its supplier,
//and is protected under applicable copyright laws. All rights are   
//reserved. Any use in violation of the foregoing restrictions may   
//subject the user to criminal sanctions under applicable laws, as   
//well as to civil liability for the breach of the terms and         
//conditions of this license.                                        
//                                                                    
//THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,  
//WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED  
//TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A       
//PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,  
//IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR         
//CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.       
// *******************************************************************/