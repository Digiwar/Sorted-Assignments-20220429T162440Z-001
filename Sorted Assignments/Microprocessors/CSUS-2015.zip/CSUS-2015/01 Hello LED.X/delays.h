/* 
 * File:   delays.h
 * Author: David Stokes
 *
 * Created on July 31, 2015, 4:32 PM
 */


// Function Prototype 

void delay(int); 


