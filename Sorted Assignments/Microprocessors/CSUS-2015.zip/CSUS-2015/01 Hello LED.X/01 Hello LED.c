/*********************************************************************
 
   01 Hello.c
 
    Modified  August 3, 2013
              David Stokes
 
      For use with PICKIt3 Debug Express
 * 
 * This project sets the pin associated PORTD bit 7 ( RD7) as an output pin by
 * placing a '0' in bit 7 of the TRISD register.  An LED is connected to
 * RD7 such that writing a '1' to LATD pin 7 causing the LED to go on.
 * 
 *   LICENSE AGREEMENT at the bottom of this file
 * 
*/

/** C O N F I G U R A T I O N   B I T S ******************************/

#pragma config FOSC = INTIO67
#pragma config WDTEN = OFF, LVP = OFF, MCLRE = ON


/** I N C L U D E S **************************************************/
#include <xc.h>


/** D E C L A R A T I O N S ******************************************/


void main (void)
{

	     TRISD = 0x7f; 	// PORTD bit 7 to output (0); bits 6:0 are inputs (1)

   //	LATDbits.LATD7 = 1;		// Set LAT register bit 7 to turn on LED
        LATD = 0x80 ;
	while (1) ;
	
}


//******************************************************************************
//Software License Agreement                                         
//                                                                    
//The software supplied herewith by Microchip Technology             
//Incorporated (the "Company") is intended and supplied to you, the  
//Company?s customer, for use solely and exclusively on Microchip    
//products. The software is owned by the Company and/or its supplier,
//and is protected under applicable copyright laws. All rights are   
//reserved. Any use in violation of the foregoing restrictions may   
//subject the user to criminal sanctions under applicable laws, as   
//well as to civil liability for the breach of the terms and         
//conditions of this license.                                        
//                                                                    
//THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,  
//WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED  
//TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A       
//PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,  
//IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR         
//CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.       
// *******************************************************************/