     
/*******************************************************************
 * 
 *  Delay function for PICKit3 labs 
 * 
 * Create  August 3, 2015
 * Author  David Stokes
 * 
 *  Intended for use with the PICKit3 Debug Express  
 *

 * This functions provides for a delay in the application code.  The amount of
 * time used in this function is controlled by the parameter passed
 * 
 * Using blocking functions, such as the one use here to implement a delay is 
 * NOT considered a proper programming practice.  Using a timer
 * for a delay is the appropriate tactic.  This method is used here for simplicity 
 * allowing the student to focus on the main code

//
// *******************************************************************
//  License agreement at bottom of this file          *
// ********************************************************************/ 


 void delay(int x)
{
    int i, j ;
    for ( i=0 ; i < x ; i++)
        for (j=0; j< 1000; j++) ;
}



//******************************************************************************
//Software License Agreement                                         
//                                                                    
//The software supplied herewith by Microchip Technology             
//Incorporated (the "Company") is intended and supplied to you, the  
//Company�s customer, for use solely and exclusively on Microchip    
//products. The software is owned by the Company and/or its supplier,
//and is protected under applicable copyright laws. All rights are   
//reserved. Any use in violation of the foregoing restrictions may   
//subject the user to criminal sanctions under applicable laws, as   
//well as to civil liability for the breach of the terms and         
//conditions of this license.                                        
//                                                                    
//THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,  
//WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED  
//TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A       
//PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,  
//IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR         
//CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.  

