// infix.java
import java.io.*;
import StackQueue.*;

class infix {
	static Queue infixToPostfix(String s) {
	}

	static int evaluePostfix(Queue Post) {
	}

	public static void main(String[] args) throws IOException {
	Queue Post;
	while(true) {
		System.out.print("Enter infix: ");
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(isr);
		String s = br.readLine();
		if ( s.equals("") ) break;
		Post = infixToPostfix(s);
		System.out.println("Postfix is " + Post.toString() + '\n');
		int result = evaluePostfix(Post);
		System.out.println("Result is " + result + '\n');
	}
     }
}
