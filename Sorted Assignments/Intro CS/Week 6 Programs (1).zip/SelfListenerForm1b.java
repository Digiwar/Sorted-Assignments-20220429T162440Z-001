package com.mycompany.myapp;

import com.codename1.ui.Button;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;

/** Code for a form with a single button which the form listens to. */
public class SelfListenerForm1b extends Form implements ActionListener {
	public SelfListenerForm1b () {
		// create a new button
        Button myButton = new Button ("Button");
		// add the button to the content pane of this form
		add(myButton);
		// register THIS object (the form) as an Action Listener for
        //  action events from the button
        myButton.addActionListener(this);
        show();
  	}
  	// Action Listener method: called from the button because
  	// this object -- the form -- is an action listener for the button
  	public void actionPerformed (ActionEvent e) {
        System.out.println ("Button Pushed (printed from the form)...");
  	}

}

