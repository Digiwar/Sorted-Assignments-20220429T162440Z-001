package com.mycompany.myapp;

import com.codename1.ui.Button;
import com.codename1.ui.Form;

public class UsingListener1a extends Form {
	public UsingListener1a() {
	//create a button
	Button myButton = new Button("Button");
	//�[style the button and add it to the form]
	//create a separate ActionListener for the button
	ButtonListener1a myButtonListener = new ButtonListener1a ();
	//register the myButtonListener as an Action Listener for
	//action events from the button
	myButton.addActionListener(myButtonListener);
	this.add(myButton);
	this.show();
	}
}
